# Feature Configuration Guide

## Overview
Zupreme Imports is built with a comprehensive configuration system that allows you to enable, disable, and customize every aspect of your store.

## Configuration Levels

### 1. Feature Flags
Global on/off switches for major features:

```typescript
// Location: shared/config.ts
export const FeatureFlags = {
  CHATBOT_ENABLED: true,           // ZED customer support chatbot
  SPORTS_CARDS_VAULT: true,       // Dedicated sports cards section
  AUTODS_INTEGRATION: true,       // Dropshipping automation
  SHOPIFY_SYNC: true,            // Marketplace integration
  EBAY_SYNC: true,               // Auction platform integration
  CONTACT_FORM: true,            // Customer contact form
  WISHLIST: false,               // Customer wishlist feature
  REVIEWS: false,                // Product review system
  LOYALTY_PROGRAM: false,        // Customer loyalty rewards
  ADVANCED_ANALYTICS: false,     // Detailed reporting
  BULK_OPERATIONS: true,         // Mass product operations
  API_ACCESS: false              // External API access
};
```

### 2. Store Configuration
Detailed settings for each feature area:

#### Store Information
```typescript
store: {
  name: "Zupreme Imports",
  description: "Premium vintage sports cards...",
  contactEmail: "support@zupremeimports.com",
  phone: "+1 (555) 123-4567",
  address: "Optional business address",
  timezone: "America/New_York"
}
```

#### Payment Settings
```typescript
payment: {
  stripe: true,                  // Credit/debit cards
  paypal: true,                  // PayPal payments
  crypto: false,                 // Cryptocurrency
  shippingRate: 5.99,           // Standard shipping cost
  freeShippingThreshold: 50.00, // Free shipping minimum
  taxRate: 8.25,                // Tax percentage
  currency: "USD"               // Store currency
}
```

#### Automation Configuration
```typescript
automation: {
  autoImport: true,             // Auto-import products
  priceMonitoring: true,        // Monitor price changes
  stockSync: true,              // Sync inventory levels
  syncFrequency: "hourly",      // How often to sync
  orderAlerts: true,            // New order notifications
  stockAlerts: true,            // Low stock warnings
  syncErrors: true,             // Error notifications
  lowStockThreshold: 5          // Stock alert trigger
}
```

## Feature-Specific Configuration

### Chatbot (ZED)
**Location**: `client/src/components/chatbot.tsx`

```typescript
const ChatbotConfig = {
  enabled: true,
  name: "ZED",
  theme: "purple",
  position: "bottom-right",
  welcomeMessage: "Hi! I'm ZED, your shopping assistant.",
  features: {
    productSearch: true,
    orderTracking: true,
    supportTickets: true,
    liveChat: false
  }
};
```

### Sports Cards Vault
**Location**: `client/src/pages/sports-cards.tsx`

```typescript
const SportsCardsConfig = {
  enabled: true,
  featuredCount: 6,
  categories: ["basketball", "baseball", "football", "hockey"],
  grading: ["mint", "near-mint", "excellent", "good"],
  decades: ["1980s", "1990s", "2000s", "2010s"],
  autoEbaySync: true,
  auctionDuration: 7
};
```

### AutoDS Integration
**Location**: `server/routes.ts`

```typescript
const AutoDSConfig = {
  enabled: true,
  apiEndpoint: "https://api.autods.com",
  syncInterval: "hourly",
  productLimit: 1000,
  categories: ["electronics", "collectibles", "sports"],
  markupPercentage: 20,
  autoPublish: true
};
```

### Marketplace Sync
**Location**: `shared/config.ts`

```typescript
marketplace: {
  shopify: {
    enabled: true,
    storeUrl: "zupreme-imports.myshopify.com",
    autoSync: true,
    syncInventory: true,
    syncPrices: true
  },
  ebay: {
    enabled: true,
    sellerId: "zupreme_imports",
    autoList: true,
    listingFormat: "auction",
    defaultDuration: 7,
    autoRelist: true,
    acceptOffers: false
  }
}
```

## Configuration Management

### Runtime Configuration
Change settings through the admin dashboard without code changes:

1. **Admin Dashboard** → **Settings Tab**
2. **Select Configuration Category**
3. **Update Values**
4. **Save Changes**

### Database Storage
Configuration is stored in the database for persistence:

```sql
CREATE TABLE store_config (
  id SERIAL PRIMARY KEY,
  section VARCHAR(50) NOT NULL,
  key VARCHAR(100) NOT NULL,
  value JSONB NOT NULL,
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Environment Variables
Critical settings use environment variables:

```bash
# Required for production
STRIPE_SECRET_KEY=sk_live_...
SHOPIFY_API_KEY=...
EBAY_API_KEY=...
AUTODS_API_KEY=...

# Optional features
OPENAI_API_KEY=...  # For enhanced chatbot
SENDGRID_API_KEY=... # For email notifications
```

## Feature Toggles

### Admin Interface
Enable/disable features through the admin panel:

**Settings** → **Features** → **Feature Management**

- Toggle switches for each feature
- Immediate effect (no restart required)
- Dependency warnings (e.g., eBay requires sports cards)

### Code-Level Toggles
For development and testing:

```typescript
// Feature guard example
if (FeatureFlags.CHATBOT_ENABLED) {
  // Render chatbot component
  return <Chatbot config={chatbotConfig} />;
}

// Conditional API endpoints
if (config.features.wishlist) {
  app.post('/api/wishlist', handleWishlist);
}
```

## Configuration Validation

### Schema Validation
All configuration uses Zod schemas for type safety:

```typescript
const ConfigSchema = z.object({
  store: StoreSchema,
  payment: PaymentSchema,
  automation: AutomationSchema,
  // ... other schemas
});

// Validate before saving
const validConfig = ConfigSchema.parse(userInput);
```

### Error Handling
Invalid configurations are caught and reported:

```typescript
try {
  const config = await loadConfig();
  validateConfig(config);
} catch (error) {
  console.error('Configuration error:', error);
  // Fall back to defaults
  return defaultConfig;
}
```

## Performance Considerations

### Lazy Loading
Features are loaded only when enabled:

```typescript
// Dynamic imports for optional features
const Wishlist = lazy(() => 
  config.features.wishlist 
    ? import('./components/Wishlist')
    : Promise.resolve({ default: () => null })
);
```

### Caching
Configuration is cached for performance:

```typescript
// Redis cache for configuration
const configCache = new Redis();
const cachedConfig = await configCache.get('store:config');
```

### Bundle Optimization
Disabled features are excluded from production builds:

```typescript
// Webpack configuration
module.exports = {
  plugins: [
    new DefinePlugin({
      'process.env.FEATURES': JSON.stringify(enabledFeatures)
    })
  ]
};
```

## Testing Configuration

### Unit Tests
Test configuration validation:

```typescript
describe('Store Configuration', () => {
  it('validates payment settings', () => {
    const config = { payment: { stripe: true } };
    expect(PaymentSchema.parse(config.payment)).toBeDefined();
  });
});
```

### Integration Tests
Test feature toggles:

```typescript
describe('Feature Toggles', () => {
  it('disables chatbot when feature flag is false', () => {
    FeatureFlags.CHATBOT_ENABLED = false;
    render(<App />);
    expect(screen.queryByTestId('chatbot')).toBeNull();
  });
});
```

## Migration Guide

### Version Updates
Handle configuration changes between versions:

```typescript
const migrations = {
  '1.0.0': (config) => {
    // Add new feature flags
    config.features.loyalty = false;
    return config;
  },
  '1.1.0': (config) => {
    // Update payment structure
    config.payment.cryptocurrency = config.payment.crypto;
    delete config.payment.crypto;
    return config;
  }
};
```

### Backup and Restore
Before major changes:

```bash
# Export current configuration
curl -X GET /api/admin/config/export > config-backup.json

# Restore from backup
curl -X POST /api/admin/config/import -d @config-backup.json
```

## Security Considerations

### Access Control
Configuration changes require admin privileges:

```typescript
app.put('/api/admin/config', requireAuth, requireAdmin, updateConfig);
```

### Sensitive Data
Encrypt sensitive configuration:

```typescript
const encryptedApiKey = encrypt(apiKey, process.env.ENCRYPTION_KEY);
await saveConfig({ apiKey: encryptedApiKey });
```

### Audit Trail
Log all configuration changes:

```typescript
const auditLog = {
  user: req.user.id,
  action: 'config_update',
  section: 'payment',
  changes: diff(oldConfig, newConfig),
  timestamp: new Date()
};
```

---

This configuration system provides complete control over your Zupreme Imports store while maintaining performance and security.