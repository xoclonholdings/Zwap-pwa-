# Zupreme Imports Admin Setup Guide

## Table of Contents
1. [Getting Started](#getting-started)
2. [Admin Login](#admin-login)
3. [Dashboard Overview](#dashboard-overview)
4. [Product Management](#product-management)
5. [Marketplace Integration](#marketplace-integration)
6. [Store Settings](#store-settings)
7. [Automation Setup](#automation-setup)
8. [Troubleshooting](#troubleshooting)

## Getting Started

### Initial Access
1. Navigate to `/admin/login` in your browser
2. Use the default credentials:
   - **Username**: `admin`
   - **Password**: `zupreme2025`
3. Change the default password immediately in Settings > Security

### First-Time Setup Checklist
- [ ] Change admin password
- [ ] Update store information
- [ ] Configure payment settings
- [ ] Set up marketplace integrations
- [ ] Test product creation
- [ ] Configure automation settings

## Admin Login

### Security Features
- **Session Management**: Auto-logout after 30 minutes of inactivity
- **Login Alerts**: Email notifications for admin logins
- **Failed Attempts**: Account lockout after 5 failed attempts

### Password Requirements
- Minimum 8 characters
- Mix of letters, numbers, and symbols recommended
- Change password every 90 days

## Dashboard Overview

The admin dashboard contains 6 main tabs:

### 1. Overview Tab
- **Total Products**: Current inventory count
- **Revenue**: Total sales amount
- **Orders**: Number of completed orders
- **Growth**: Performance metrics

### 2. Products Tab
- View all products in your inventory
- Edit product details with inline editing
- Delete products with confirmation
- Filter and search functionality

### 3. Upload Tab
- Add new products to your store
- Configure marketplace sync options
- Set product categories and details
- Bulk upload capabilities (CSV import)

### 4. Shopify Tab
- Monitor Shopify integration status
- Sync all products to Shopify
- Configure sync settings
- View sync history and errors

### 5. eBay Tab
- Manage eBay sports card listings
- Configure listing formats and duration
- Monitor active auctions
- Track sold items and fees

### 6. Settings Tab
- Store configuration
- Payment and shipping setup
- Automation preferences
- SEO and marketing tools
- Security settings

## Product Management

### Adding Products

1. **Go to Upload Tab**
2. **Fill Required Fields**:
   - Product Name
   - Description
   - Price
   - Category
   - Image URL

3. **Sports Cards Additional Fields**:
   - Player Name
   - Team
   - Year
   - Condition
   - Sport

4. **Marketplace Sync Options**:
   - ✅ Sync to Shopify (all products)
   - ✅ Sync to eBay (sports cards only)

### Editing Products

1. **Navigate to Products Tab**
2. **Click Edit Button** (pencil icon)
3. **Update Fields** in the Upload tab
4. **Save Changes**

### Deleting Products

1. **Go to Products Tab**
2. **Click Delete Button** (trash icon)
3. **Confirm Deletion**
4. Product will be removed from all marketplaces

### Bulk Operations

- **CSV Import**: Upload products via CSV file
- **Bulk Edit**: Select multiple products for batch updates
- **Mass Delete**: Remove multiple products at once

## Marketplace Integration

### Shopify Setup

1. **Connection Status**: Check green "Connected" indicator
2. **Store URL**: Verify your Shopify store URL
3. **Sync Settings**:
   - Auto sync: Enable for real-time updates
   - Price sync: Automatically update prices
   - Inventory sync: Keep stock levels synchronized

4. **Manual Sync**: Use "Sync All Products" button for immediate sync

### eBay Configuration

1. **Seller ID**: Verify your eBay seller account
2. **Listing Format**:
   - Auction Style: Traditional bidding
   - Fixed Price: Buy-it-now listings
   - Both Formats: Flexible options

3. **Duration Settings**:
   - 3, 7, 10, or 30 days
   - Recommended: 7 days for sports cards

4. **Advanced Options**:
   - Auto-relist: Automatically relist unsold items
   - Best Offers: Accept buyer offers

### AutoDS Integration

- **Product Sourcing**: Automatic product import
- **Price Monitoring**: Real-time price updates
- **Stock Synchronization**: Inventory level management
- **Supplier Management**: Multiple supplier connections

## Store Settings

### Store Information
- **Store Name**: Your business name
- **Description**: Brief store description
- **Contact Details**: Email and phone
- **Business Address**: Physical location

### Payment & Shipping
- **Payment Methods**:
  - Stripe (Credit/Debit cards)
  - PayPal
  - Cryptocurrency (optional)

- **Shipping Configuration**:
  - Standard rate: $5.99
  - Free shipping threshold: $50+
  - Tax rate: 8.25% (configurable)

### SEO & Marketing
- **Meta Title**: Search engine title
- **Meta Description**: Search result snippet
- **Keywords**: SEO keyword targeting
- **Social Media**: Connect your accounts

### Security Settings
- **Password Management**: Change admin credentials
- **Two-Factor Authentication**: Enhanced security
- **Login Alerts**: Email notifications
- **Session Management**: Auto-logout configuration

## Automation Setup

### AutoDS Configuration

1. **Enable Auto-Import**: Automatically add new products
2. **Price Monitoring**: Track supplier price changes
3. **Stock Synchronization**: Update inventory levels
4. **Sync Frequency Options**:
   - Real-time: Instant updates
   - Every 15 minutes: Near real-time
   - Hourly: Standard sync
   - Daily: Basic sync

### Notification Settings

- **Order Alerts**: New order notifications
- **Stock Alerts**: Low inventory warnings
- **Sync Errors**: Integration failure alerts
- **Email Configuration**: Admin notification email

### Performance Optimization

- **Cache Management**: Clear cached data
- **Database Optimization**: Regular maintenance
- **Image Optimization**: Compress product images
- **CDN Integration**: Fast content delivery

## Troubleshooting

### Common Issues

#### Product Sync Failures
1. **Check Integration Status**: Verify Shopify/eBay connections
2. **Review Error Logs**: Look for specific error messages
3. **Retry Sync**: Use manual sync buttons
4. **Contact Support**: If issues persist

#### Login Problems
1. **Clear Browser Cache**: Remove stored data
2. **Check Credentials**: Verify username/password
3. **Reset Password**: Use password recovery
4. **Browser Compatibility**: Use supported browsers

#### Performance Issues
1. **Clear Cache**: Use cache management tools
2. **Optimize Images**: Compress large files
3. **Database Cleanup**: Remove unused data
4. **Server Resources**: Check system status

### Error Codes

- **401**: Authentication required
- **403**: Access denied
- **404**: Resource not found
- **500**: Server error
- **503**: Service unavailable

### Support Resources

- **System Health**: Check in Settings > System Maintenance
- **Backup & Recovery**: Regular data backups
- **Export Data**: Download your information
- **Documentation**: This guide and API docs

### Best Practices

1. **Regular Backups**: Weekly data exports
2. **Password Security**: Strong, unique passwords
3. **Monitoring**: Check dashboard daily
4. **Updates**: Keep system current
5. **Testing**: Verify changes in staging

### Performance Metrics

- **Page Load Speed**: < 3 seconds
- **Sync Success Rate**: > 95%
- **Uptime**: 99.9% target
- **Error Rate**: < 1%

## Advanced Features

### API Access
- **REST API**: Programmatic access
- **Webhooks**: Real-time notifications
- **Bulk Operations**: Mass data updates
- **Custom Integrations**: Third-party connections

### Analytics
- **Sales Reports**: Revenue tracking
- **Product Performance**: Best sellers
- **Customer Insights**: Buying patterns
- **Marketing Analytics**: Campaign effectiveness

### Customization
- **Theme Settings**: Visual customization
- **Feature Flags**: Enable/disable features
- **Custom Fields**: Additional product data
- **Workflow Automation**: Custom business rules

---

**Need Help?** Contact support at support@zupremeimports.com or use the built-in chat system.