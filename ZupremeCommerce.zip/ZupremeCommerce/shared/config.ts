import { z } from "zod";

// Store Configuration Schema
export const StoreConfigSchema = z.object({
  store: z.object({
    name: z.string().default("Zupreme Imports"),
    description: z.string().default("Premium vintage sports cards, trending imports, and rare collectibles"),
    contactEmail: z.string().email().default("support@zupremeimports.com"),
    phone: z.string().default("+1 (555) 123-4567"),
    address: z.string().optional(),
    timezone: z.string().default("America/New_York")
  }),
  
  payment: z.object({
    stripe: z.boolean().default(true),
    paypal: z.boolean().default(true),
    crypto: z.boolean().default(false),
    shippingRate: z.number().default(5.99),
    freeShippingThreshold: z.number().default(50.00),
    taxRate: z.number().default(8.25),
    currency: z.string().default("USD")
  }),
  
  automation: z.object({
    autoImport: z.boolean().default(true),
    priceMonitoring: z.boolean().default(true),
    stockSync: z.boolean().default(true),
    syncFrequency: z.enum(["realtime", "15min", "hourly", "daily"]).default("hourly"),
    orderAlerts: z.boolean().default(true),
    stockAlerts: z.boolean().default(true),
    syncErrors: z.boolean().default(true),
    lowStockThreshold: z.number().default(5)
  }),
  
  seo: z.object({
    metaTitle: z.string().default("Zupreme Imports - Premium Sports Cards & Collectibles"),
    metaDescription: z.string().default("Discover rare vintage sports cards, trending imports, and premium collectibles"),
    keywords: z.string().default("sports cards, collectibles, vintage cards, trading cards, memorabilia"),
    socialMedia: z.object({
      facebook: z.string().optional(),
      instagram: z.string().optional(),
      twitter: z.string().optional(),
      youtube: z.string().optional()
    }),
    googleAnalytics: z.string().optional(),
    facebookPixel: z.string().optional()
  }),
  
  security: z.object({
    twoFactor: z.boolean().default(false),
    loginAlerts: z.boolean().default(true),
    autoLogout: z.boolean().default(true),
    sessionTimeout: z.number().default(30), // minutes
    maxLoginAttempts: z.number().default(5),
    passwordMinLength: z.number().default(8)
  }),
  
  features: z.object({
    chatbot: z.boolean().default(true),
    sportsCardsVault: z.boolean().default(true),
    autoDsIntegration: z.boolean().default(true),
    shopifySync: z.boolean().default(true),
    ebaySync: z.boolean().default(true),
    contactForm: z.boolean().default(true),
    wishlist: z.boolean().default(false),
    reviews: z.boolean().default(false),
    loyalty: z.boolean().default(false)
  }),
  
  ui: z.object({
    theme: z.enum(["light", "dark", "auto"]).default("light"),
    primaryColor: z.string().default("#7c3aed"), // Purple
    accentColor: z.string().default("#10b981"), // Green
    fontFamily: z.string().default("Inter"),
    headerStyle: z.enum(["modern", "classic", "minimal"]).default("modern"),
    showPrices: z.boolean().default(true),
    showStock: z.boolean().default(true)
  }),
  
  marketplace: z.object({
    shopify: z.object({
      enabled: z.boolean().default(true),
      storeUrl: z.string().optional(),
      autoSync: z.boolean().default(true),
      syncInventory: z.boolean().default(true),
      syncPrices: z.boolean().default(true)
    }),
    ebay: z.object({
      enabled: z.boolean().default(true),
      sellerId: z.string().optional(),
      autoList: z.boolean().default(true),
      listingFormat: z.enum(["auction", "fixed", "both"]).default("auction"),
      defaultDuration: z.number().default(7),
      autoRelist: z.boolean().default(true),
      acceptOffers: z.boolean().default(false)
    })
  })
});

export type StoreConfig = z.infer<typeof StoreConfigSchema>;

// Default configuration
export const defaultConfig: StoreConfig = StoreConfigSchema.parse({});

// Feature flags for easy enable/disable
export const FeatureFlags = {
  CHATBOT_ENABLED: true,
  SPORTS_CARDS_VAULT: true,
  AUTODS_INTEGRATION: true,
  SHOPIFY_SYNC: true,
  EBAY_SYNC: true,
  CONTACT_FORM: true,
  WISHLIST: false,
  REVIEWS: false,
  LOYALTY_PROGRAM: false,
  ADVANCED_ANALYTICS: false,
  BULK_OPERATIONS: true,
  API_ACCESS: false
} as const;

export type FeatureFlag = keyof typeof FeatureFlags;