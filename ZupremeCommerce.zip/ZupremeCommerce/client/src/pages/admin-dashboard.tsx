import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Package, 
  Plus, 
  LogOut, 
  Upload, 
  Trash2, 
  Edit, 
  BarChart3,
  Users,
  ShoppingCart,
  DollarSign,
  RefreshCw,
  ExternalLink,
  CheckCircle,
  AlertCircle,
  Clock,
  Settings,
  CreditCard,
  Zap,
  Search,
  Database,
  Download,
  Shield,
  Lock
} from "lucide-react";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");
  const [editingProduct, setEditingProduct] = useState<any>(null);

  // Check authentication
  useEffect(() => {
    const token = localStorage.getItem("adminToken");
    if (!token) {
      setLocation("/admin/login");
    }
  }, [setLocation]);

  // Product form state
  const [productForm, setProductForm] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    imageUrl: "",
    ebayListingUrl: "",
    condition: "",
    year: "",
    player: "",
    team: "",
    sport: ""
  });

  // Fetch admin stats
  const { data: stats } = useQuery({
    queryKey: ["/api/admin/stats"],
  });

  // Fetch Shopify status
  const { data: shopifyStatus } = useQuery({
    queryKey: ["/api/admin/shopify/status"],
  });

  // Fetch eBay status
  const { data: ebayStatus } = useQuery({
    queryKey: ["/api/admin/ebay/status"],
  });

  // Fetch all products for management
  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ["/api/admin/products"],
  });

  // Add product mutation
  const addProductMutation = useMutation({
    mutationFn: (productData: any) => apiRequest("POST", "/api/admin/products", productData),
    onSuccess: () => {
      toast({ title: "Success", description: "Product added successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/products"] });
      resetForm();
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to add product",
        variant: "destructive" 
      });
    }
  });

  // Update product mutation
  const updateProductMutation = useMutation({
    mutationFn: ({ id, data }: { id: string, data: any }) => 
      apiRequest("PUT", `/api/admin/products/${id}`, data),
    onSuccess: () => {
      toast({ title: "Success", description: "Product updated successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/products"] });
      setEditingProduct(null);
      resetForm();
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to update product",
        variant: "destructive" 
      });
    }
  });

  // Delete product mutation
  const deleteProductMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/admin/products/${id}`),
    onSuccess: () => {
      toast({ title: "Success", description: "Product deleted successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/products"] });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to delete product",
        variant: "destructive" 
      });
    }
  });

  // Shopify sync mutation
  const shopifySyncMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/admin/shopify/sync"),
    onSuccess: () => {
      toast({ title: "Success", description: "Shopify sync completed" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/shopify/status"] });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Shopify sync failed",
        variant: "destructive" 
      });
    }
  });

  // eBay sync mutation
  const ebaySyncMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/admin/ebay/sync"),
    onSuccess: () => {
      toast({ title: "Success", description: "eBay sync completed" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/ebay/status"] });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "eBay sync failed",
        variant: "destructive" 
      });
    }
  });

  const resetForm = () => {
    setProductForm({
      name: "",
      description: "",
      price: "",
      category: "",
      imageUrl: "",
      ebayListingUrl: "",
      condition: "",
      year: "",
      player: "",
      team: "",
      sport: ""
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setProductForm(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const productData = {
      ...productForm,
      price: parseFloat(productForm.price),
      year: productForm.year ? parseInt(productForm.year) : null
    };

    if (editingProduct) {
      updateProductMutation.mutate({ id: editingProduct.id, data: productData });
    } else {
      addProductMutation.mutate(productData);
    }
  };

  const handleEdit = (product: any) => {
    setEditingProduct(product);
    setProductForm({
      name: product.name || "",
      description: product.description || "",
      price: product.price?.toString() || "",
      category: product.category || "",
      imageUrl: product.imageUrl || "",
      ebayListingUrl: product.ebayListingUrl || "",
      condition: product.condition || "",
      year: product.year?.toString() || "",
      player: product.player || "",
      team: product.team || "",
      sport: product.sport || ""
    });
    setActiveTab("products");
  };

  const handleLogout = () => {
    localStorage.removeItem("adminToken");
    toast({ title: "Logged out", description: "You have been signed out" });
    setLocation("/admin/login");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Package className="w-8 h-8 text-purple-600" />
              <h1 className="text-xl font-bold text-gray-900">Zupreme Admin</h1>
            </div>
            <Button 
              variant="outline" 
              onClick={handleLogout}
              className="flex items-center space-x-2"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="upload">Upload</TabsTrigger>
            <TabsTrigger value="shopify">Shopify</TabsTrigger>
            <TabsTrigger value="ebay">eBay</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <ShoppingCart className="w-5 h-5 text-blue-600" />
                    <span className="text-sm font-medium text-gray-600">Total Products</span>
                  </div>
                  <p className="text-2xl font-bold text-gray-900 mt-2">
                    {(stats as any)?.totalProducts || 0}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <DollarSign className="w-5 h-5 text-green-600" />
                    <span className="text-sm font-medium text-gray-600">Revenue</span>
                  </div>
                  <p className="text-2xl font-bold text-gray-900 mt-2">
                    ${(stats as any)?.revenue || 0}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <Users className="w-5 h-5 text-purple-600" />
                    <span className="text-sm font-medium text-gray-600">Orders</span>
                  </div>
                  <p className="text-2xl font-bold text-gray-900 mt-2">
                    {(stats as any)?.totalOrders || 0}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <BarChart3 className="w-5 h-5 text-orange-600" />
                    <span className="text-sm font-medium text-gray-600">Growth</span>
                  </div>
                  <p className="text-2xl font-bold text-gray-900 mt-2">
                    +{(stats as any)?.growth || 0}%
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Product Management</CardTitle>
              </CardHeader>
              <CardContent>
                {productsLoading ? (
                  <p>Loading products...</p>
                ) : (
                  <div className="space-y-4">
                    {(products as any[])?.map((product: any) => (
                      <div key={product.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex-1">
                          <h3 className="font-semibold">{product.name}</h3>
                          <p className="text-sm text-gray-600">{product.description}</p>
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge variant="secondary">${product.price}</Badge>
                            {product.category && <Badge variant="outline">{product.category}</Badge>}
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(product)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => deleteProductMutation.mutate(product.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Upload Tab */}
          <TabsContent value="upload" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>
                  {editingProduct ? "Edit Product" : "Add New Product"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Product Name</Label>
                      <Input
                        id="name"
                        value={productForm.name}
                        onChange={(e) => handleInputChange("name", e.target.value)}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="price">Price ($)</Label>
                      <Input
                        id="price"
                        type="number"
                        step="0.01"
                        value={productForm.price}
                        onChange={(e) => handleInputChange("price", e.target.value)}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Select value={productForm.category} onValueChange={(value) => handleInputChange("category", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sports-cards">Sports Cards</SelectItem>
                          <SelectItem value="electronics">Electronics</SelectItem>
                          <SelectItem value="collectibles">Collectibles</SelectItem>
                          <SelectItem value="accessories">Accessories</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="condition">Condition</Label>
                      <Select value={productForm.condition} onValueChange={(value) => handleInputChange("condition", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select condition" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="mint">Mint</SelectItem>
                          <SelectItem value="near-mint">Near Mint</SelectItem>
                          <SelectItem value="excellent">Excellent</SelectItem>
                          <SelectItem value="good">Good</SelectItem>
                          <SelectItem value="fair">Fair</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="year">Year</Label>
                      <Input
                        id="year"
                        type="number"
                        value={productForm.year}
                        onChange={(e) => handleInputChange("year", e.target.value)}
                      />
                    </div>

                    <div>
                      <Label htmlFor="player">Player</Label>
                      <Input
                        id="player"
                        value={productForm.player}
                        onChange={(e) => handleInputChange("player", e.target.value)}
                      />
                    </div>

                    <div>
                      <Label htmlFor="team">Team</Label>
                      <Input
                        id="team"
                        value={productForm.team}
                        onChange={(e) => handleInputChange("team", e.target.value)}
                      />
                    </div>

                    <div>
                      <Label htmlFor="sport">Sport</Label>
                      <Select value={productForm.sport} onValueChange={(value) => handleInputChange("sport", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select sport" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="basketball">Basketball</SelectItem>
                          <SelectItem value="football">Football</SelectItem>
                          <SelectItem value="baseball">Baseball</SelectItem>
                          <SelectItem value="hockey">Hockey</SelectItem>
                          <SelectItem value="soccer">Soccer</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={productForm.description}
                      onChange={(e) => handleInputChange("description", e.target.value)}
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="imageUrl">Image URL</Label>
                    <Input
                      id="imageUrl"
                      type="url"
                      value={productForm.imageUrl}
                      onChange={(e) => handleInputChange("imageUrl", e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="ebayListingUrl">eBay Listing URL</Label>
                    <Input
                      id="ebayListingUrl"
                      type="url"
                      value={productForm.ebayListingUrl}
                      onChange={(e) => handleInputChange("ebayListingUrl", e.target.value)}
                    />
                  </div>

                  {/* Sync Options */}
                  <div className="pt-4 border-t">
                    <Label className="text-base font-semibold">Marketplace Sync</Label>
                    <div className="mt-3 space-y-3">
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <input
                          type="checkbox"
                          id="syncToShopify"
                          className="h-4 w-4 text-purple-600"
                        />
                        <div className="flex-1">
                          <Label htmlFor="syncToShopify" className="font-medium">
                            Sync to Shopify Marketplace
                          </Label>
                          <p className="text-sm text-gray-500">
                            Automatically create/update listing on Shopify store
                          </p>
                        </div>
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          All Products
                        </Badge>
                      </div>

                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <input
                          type="checkbox"
                          id="syncToEbay"
                          className="h-4 w-4 text-blue-600"
                          disabled={productForm.category !== "sports-cards"}
                        />
                        <div className="flex-1">
                          <Label 
                            htmlFor="syncToEbay" 
                            className={`font-medium ${
                              productForm.category !== "sports-cards" ? "text-gray-400" : ""
                            }`}
                          >
                            Create eBay Listing
                          </Label>
                          <p className="text-sm text-gray-500">
                            {productForm.category === "sports-cards" 
                              ? "Create auction or fixed-price listing on eBay"
                              : "Only available for sports cards"
                            }
                          </p>
                        </div>
                        <Badge 
                          variant="secondary" 
                          className={
                            productForm.category === "sports-cards"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-gray-100 text-gray-600"
                          }
                        >
                          Sports Cards Only
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-4">
                    <Button 
                      type="submit" 
                      disabled={addProductMutation.isPending || updateProductMutation.isPending}
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      {editingProduct ? "Update Product" : "Add Product"}
                    </Button>

                    {editingProduct && (
                      <Button 
                        type="button" 
                        variant="outline"
                        onClick={() => {
                          setEditingProduct(null);
                          resetForm();
                        }}
                      >
                        Cancel Edit
                      </Button>
                    )}
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Shopify Tab */}
          <TabsContent value="shopify" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <ExternalLink className="w-5 h-5" />
                    <span>Shopify Integration</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="font-medium">Connected</span>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Active
                    </Badge>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Store URL:</span>
                      <span className="font-medium">{(shopifyStatus as any)?.storeUrl || "Not configured"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Synced Products:</span>
                      <span className="font-medium">{(shopifyStatus as any)?.products || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Last Sync:</span>
                      <span className="font-medium text-sm">
                        {(shopifyStatus as any)?.lastSync ? 
                          new Date((shopifyStatus as any).lastSync).toLocaleString() : 
                          "Never"
                        }
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <Button 
                      onClick={() => shopifySyncMutation.mutate()}
                      disabled={shopifySyncMutation.isPending}
                      className="w-full"
                    >
                      {shopifySyncMutation.isPending ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Syncing...
                        </>
                      ) : (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2" />
                          Sync All Products
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Sync Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <Label>Auto Sync Options</Label>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="auto-sync" defaultChecked />
                        <Label htmlFor="auto-sync" className="text-sm">Enable automatic sync</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="price-sync" defaultChecked />
                        <Label htmlFor="price-sync" className="text-sm">Sync price changes</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="inventory-sync" />
                        <Label htmlFor="inventory-sync" className="text-sm">Sync inventory levels</Label>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <Label>Sync Frequency</Label>
                    <Select defaultValue="hourly">
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="realtime">Real-time</SelectItem>
                        <SelectItem value="hourly">Every hour</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="manual">Manual only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* eBay Tab */}
          <TabsContent value="ebay" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <ExternalLink className="w-5 h-5" />
                    <span>eBay Integration</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-5 h-5 text-blue-600" />
                      <span className="font-medium">Connected</span>
                    </div>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                      Sports Cards Only
                    </Badge>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Seller ID:</span>
                      <span className="font-medium">{(ebayStatus as any)?.sellerId || "Not configured"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Active Listings:</span>
                      <span className="font-medium">{(ebayStatus as any)?.activeListings || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Sold Items:</span>
                      <span className="font-medium">{(ebayStatus as any)?.soldItems || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Last Sync:</span>
                      <span className="font-medium text-sm">
                        {(ebayStatus as any)?.lastSync ? 
                          new Date((ebayStatus as any).lastSync).toLocaleString() : 
                          "Never"
                        }
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <Button 
                      onClick={() => ebaySyncMutation.mutate()}
                      disabled={ebaySyncMutation.isPending}
                      className="w-full"
                      variant="outline"
                    >
                      {ebaySyncMutation.isPending ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Syncing...
                        </>
                      ) : (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2" />
                          Sync Sports Cards
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>eBay Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <Label>Listing Format</Label>
                      <Select defaultValue="auction">
                        <SelectTrigger className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="auction">Auction Style</SelectItem>
                          <SelectItem value="fixed">Fixed Price</SelectItem>
                          <SelectItem value="both">Both Formats</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Default Duration</Label>
                      <Select defaultValue="7">
                        <SelectTrigger className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="3">3 days</SelectItem>
                          <SelectItem value="7">7 days</SelectItem>
                          <SelectItem value="10">10 days</SelectItem>
                          <SelectItem value="30">30 days</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="auto-relist" defaultChecked />
                        <Label htmlFor="auto-relist" className="text-sm">Auto-relist unsold items</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="best-offer" />
                        <Label htmlFor="best-offer" className="text-sm">Accept best offers</Label>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <div className="text-sm text-gray-600">
                      <p className="font-medium mb-1">Fee Structure:</p>
                      <p>Listing: ${(ebayStatus as any)?.fees?.listing || 0.35}</p>
                      <p>Final Value: {(ebayStatus as any)?.fees?.final || 10.2}%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Store Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Settings className="w-5 h-5" />
                    <span>Store Information</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="store-name">Store Name</Label>
                    <Input
                      id="store-name"
                      defaultValue="Zupreme Imports"
                      className="mt-2"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="store-description">Store Description</Label>
                    <textarea
                      id="store-description"
                      className="w-full mt-2 p-3 border rounded-lg resize-none"
                      rows={3}
                      defaultValue="Premium vintage sports cards, trending imports, and rare collectibles. Your trusted source for authentic memorabilia and unique finds."
                    />
                  </div>

                  <div>
                    <Label htmlFor="contact-email">Contact Email</Label>
                    <Input
                      id="contact-email"
                      type="email"
                      defaultValue="support@zupremeimports.com"
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      defaultValue="+1 (555) 123-4567"
                      className="mt-2"
                    />
                  </div>

                  <Button className="w-full mt-4">
                    Save Store Information
                  </Button>
                </CardContent>
              </Card>

              {/* Payment & Shipping */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <CreditCard className="w-5 h-5" />
                    <span>Payment & Shipping</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Payment Methods</Label>
                    <div className="space-y-2 mt-2">
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="stripe" defaultChecked />
                        <Label htmlFor="stripe" className="text-sm">Stripe (Credit/Debit Cards)</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="paypal" defaultChecked />
                        <Label htmlFor="paypal" className="text-sm">PayPal</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="crypto" />
                        <Label htmlFor="crypto" className="text-sm">Cryptocurrency</Label>
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="shipping-rate">Standard Shipping Rate ($)</Label>
                    <Input
                      id="shipping-rate"
                      type="number"
                      step="0.01"
                      defaultValue="5.99"
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="free-shipping">Free Shipping Threshold ($)</Label>
                    <Input
                      id="free-shipping"
                      type="number"
                      step="0.01"
                      defaultValue="50.00"
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="tax-rate">Tax Rate (%)</Label>
                    <Input
                      id="tax-rate"
                      type="number"
                      step="0.01"
                      defaultValue="8.25"
                      className="mt-2"
                    />
                  </div>

                  <Button className="w-full mt-4" variant="outline">
                    Update Payment Settings
                  </Button>
                </CardContent>
              </Card>

              {/* Automation Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Zap className="w-5 h-5" />
                    <span>Automation Settings</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-base font-medium">AutoDS Configuration</Label>
                    <div className="space-y-3 mt-2">
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="auto-import" defaultChecked />
                        <Label htmlFor="auto-import" className="text-sm">Auto-import new products</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="price-monitoring" defaultChecked />
                        <Label htmlFor="price-monitoring" className="text-sm">Price monitoring & updates</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="stock-sync" defaultChecked />
                        <Label htmlFor="stock-sync" className="text-sm">Stock level synchronization</Label>
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="sync-frequency">Sync Frequency</Label>
                    <Select defaultValue="hourly">
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="realtime">Real-time</SelectItem>
                        <SelectItem value="15min">Every 15 minutes</SelectItem>
                        <SelectItem value="hourly">Hourly</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-base font-medium">Notification Settings</Label>
                    <div className="space-y-2 mt-2">
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="order-alerts" defaultChecked />
                        <Label htmlFor="order-alerts" className="text-sm">New order alerts</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="stock-alerts" defaultChecked />
                        <Label htmlFor="stock-alerts" className="text-sm">Low stock alerts</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="sync-errors" defaultChecked />
                        <Label htmlFor="sync-errors" className="text-sm">Sync error notifications</Label>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full mt-4">
                    Save Automation Settings
                  </Button>
                </CardContent>
              </Card>

              {/* SEO & Marketing */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Search className="w-5 h-5" />
                    <span>SEO & Marketing</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="meta-title">Meta Title</Label>
                    <Input
                      id="meta-title"
                      defaultValue="Zupreme Imports - Premium Sports Cards & Collectibles"
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="meta-description">Meta Description</Label>
                    <textarea
                      id="meta-description"
                      className="w-full mt-2 p-3 border rounded-lg resize-none"
                      rows={3}
                      defaultValue="Discover rare vintage sports cards, trending imports, and premium collectibles. Authentic memorabilia with fast shipping and satisfaction guarantee."
                    />
                  </div>

                  <div>
                    <Label htmlFor="keywords">Keywords (comma-separated)</Label>
                    <Input
                      id="keywords"
                      defaultValue="sports cards, collectibles, vintage cards, trading cards, memorabilia"
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label className="text-base font-medium">Social Media</Label>
                    <div className="space-y-2 mt-2">
                      <div className="flex items-center space-x-2">
                        <Label htmlFor="facebook" className="text-sm w-20">Facebook:</Label>
                        <Input
                          id="facebook"
                          placeholder="@zupremeimports"
                          className="flex-1"
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <Label htmlFor="instagram" className="text-sm w-20">Instagram:</Label>
                        <Input
                          id="instagram"
                          placeholder="@zupremeimports"
                          className="flex-1"
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <Label htmlFor="twitter" className="text-sm w-20">Twitter:</Label>
                        <Input
                          id="twitter"
                          placeholder="@zupremeimports"
                          className="flex-1"
                        />
                      </div>
                    </div>
                  </div>

                  <Button className="w-full mt-4" variant="outline">
                    Update SEO Settings
                  </Button>
                </CardContent>
              </Card>

              {/* System Maintenance */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Database className="w-5 h-5" />
                    <span>System Maintenance</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-base font-medium">System Diagnostics</Label>
                    <div className="space-y-3 mt-3">
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={() => {
                          apiRequest("GET", "/api/admin/diagnostics")
                            .then(res => res.json())
                            .then(data => {
                              toast({
                                title: "System Health Check",
                                description: `Overall status: ${data.overall} (Score: ${data.score}/100)`,
                                variant: data.overall === "healthy" ? "default" : "destructive"
                              });
                            });
                        }}
                      >
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Run System Diagnostics
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={() => {
                          apiRequest("POST", "/api/admin/optimize")
                            .then(res => res.json())
                            .then(data => {
                              toast({
                                title: "Storage Optimization",
                                description: data.success ? "Storage optimized successfully" : "Optimization failed",
                                variant: data.success ? "default" : "destructive"
                              });
                            });
                        }}
                      >
                        <Zap className="w-4 h-4 mr-2" />
                        Optimize Storage
                      </Button>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <Label className="text-base font-medium">Data Export</Label>
                    <div className="space-y-3 mt-3">
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={() => {
                          apiRequest("GET", "/api/admin/export/products")
                            .then(res => res.json())
                            .then(data => {
                              toast({
                                title: "Products Export",
                                description: `Exported ${data.recordCount} products`,
                              });
                            });
                        }}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Export All Products
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={() => {
                          apiRequest("GET", "/api/admin/export/sports-cards")
                            .then(res => res.json())
                            .then(data => {
                              toast({
                                title: "Sports Cards Export",
                                description: `Exported ${data.recordCount} sports cards`,
                              });
                            });
                        }}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Export Sports Cards
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={() => {
                          apiRequest("GET", "/api/admin/export/configuration")
                            .then(res => res.json())
                            .then(data => {
                              toast({
                                title: "Configuration Export",
                                description: "Store configuration exported",
                              });
                            });
                        }}
                      >
                        <Settings className="w-4 h-4 mr-2" />
                        Export Configuration
                      </Button>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <Label className="text-base font-medium">Complete Export</Label>
                    <div className="space-y-3 mt-3">
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={() => {
                          apiRequest("GET", "/api/admin/export/all")
                            .then(res => res.json())
                            .then(data => {
                              toast({
                                title: "Complete Export",
                                description: `All data exported successfully`,
                              });
                            });
                        }}
                      >
                        <Shield className="w-4 h-4 mr-2" />
                        Export All Data
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={() => {
                          apiRequest("GET", "/api/admin/export/diagnostics")
                            .then(res => res.json())
                            .then(data => {
                              toast({
                                title: "Diagnostics Report",
                                description: "System report generated",
                              });
                            });
                        }}
                      >
                        <Database className="w-4 h-4 mr-2" />
                        Generate System Report
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Security Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Lock className="w-5 h-5" />
                    <span>Security Settings</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-base font-medium">Admin Access</Label>
                    <div className="space-y-3 mt-2">
                      <div>
                        <Label htmlFor="current-password" className="text-sm">Current Password</Label>
                        <Input
                          id="current-password"
                          type="password"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="new-password" className="text-sm">New Password</Label>
                        <Input
                          id="new-password"
                          type="password"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="confirm-password" className="text-sm">Confirm Password</Label>
                        <Input
                          id="confirm-password"
                          type="password"
                          className="mt-1"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <Label className="text-base font-medium">Security Options</Label>
                    <div className="space-y-2 mt-2">
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="two-factor" />
                        <Label htmlFor="two-factor" className="text-sm">Enable two-factor authentication</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="login-alerts" defaultChecked />
                        <Label htmlFor="login-alerts" className="text-sm">Email login alerts</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="auto-logout" defaultChecked />
                        <Label htmlFor="auto-logout" className="text-sm">Auto-logout after 30 minutes</Label>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full mt-4">
                    Update Security Settings
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}