import { useEffect, useState } from "react";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useMutation } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
const stripePromise = import.meta.env.VITE_STRIPE_PUBLIC_KEY ? 
  loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY) : null;

const CheckoutForm = ({ orderDetails }: { orderDetails: any }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    email: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    if (!customerInfo.name || !customerInfo.email) {
      toast({
        title: "Missing Information",
        description: "Please fill in your name and email address.",
        variant: "destructive",
      });
      return;
    }

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Thank you for your purchase!",
      });
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <Card>
        <CardHeader>
          <CardTitle>Complete Your Order</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Order Summary */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Order Summary</h3>
            <div className="flex justify-between items-center">
              <span>{orderDetails.name}</span>
              <span className="font-bold">${orderDetails.amount}</span>
            </div>
          </div>

          {/* Customer Information */}
          <div className="space-y-4">
            <h3 className="font-semibold">Customer Information</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  type="text"
                  value={customerInfo.name}
                  onChange={(e) => setCustomerInfo(prev => ({ ...prev, name: e.target.value }))}
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={customerInfo.email}
                  onChange={(e) => setCustomerInfo(prev => ({ ...prev, email: e.target.value }))}
                  required
                />
              </div>
            </div>
          </div>

          {/* Payment Element */}
          <div>
            <h3 className="font-semibold mb-4">Payment Information</h3>
            <PaymentElement />
          </div>

          <Button
            onClick={handleSubmit}
            className="w-full brand-gradient text-white"
            disabled={!stripe}
          >
            Complete Payment
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default function Checkout() {
  const { toast } = useToast();
  const [clientSecret, setClientSecret] = useState("");
  const [orderDetails, setOrderDetails] = useState<any>(null);

  const createPaymentIntentMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/create-payment-intent", data),
    onSuccess: (response: any) => {
      response.json().then((data: any) => {
        setClientSecret(data.clientSecret);
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to initialize payment. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    // Parse URL parameters to get order details
    const urlParams = new URLSearchParams(window.location.search);
    const type = urlParams.get('type');
    const amount = parseFloat(urlParams.get('amount') || '0');
    const name = urlParams.get('name') || '';
    const id = urlParams.get('id');

    if (!amount || !name) {
      toast({
        title: "Invalid Order",
        description: "Order details are missing. Please try again.",
        variant: "destructive",
      });
      return;
    }

    const details = { type, amount, name, id };
    setOrderDetails(details);

    if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
      toast({
        title: "Payment System Unavailable",
        description: "Stripe payment system is not configured. Please contact support.",
        variant: "destructive",
      });
      return;
    }

    // Create PaymentIntent
    createPaymentIntentMutation.mutate({
      amount,
      customerEmail: "",
      customerName: "",
      items: [{ name, amount, type, id }],
    });
  }, []);

  if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-2xl mx-auto px-4 py-20 text-center">
          <Card>
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Payment System Unavailable</h2>
              <p className="text-gray-600 mb-6">
                Our payment system is currently being configured. Please contact us directly to complete your purchase.
              </p>
              <div className="space-y-2 text-sm text-gray-500">
                <p>Email: info@zupremeimports.com</p>
                <p>Phone: +1 (555) 123-4567</p>
              </div>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  if (!clientSecret || !orderDetails) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-2xl mx-auto px-4 py-20 text-center">
          <Card>
            <CardContent className="p-8">
              <div className="animate-spin w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-gray-900">Preparing your checkout...</h2>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <Elements stripe={stripePromise} options={{ clientSecret }}>
        <CheckoutForm orderDetails={orderDetails} />
      </Elements>
      <Footer />
    </div>
  );
}
