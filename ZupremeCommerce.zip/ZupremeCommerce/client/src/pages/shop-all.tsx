import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function ShopAll() {
  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ["/api/products"],
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Shop All Inventory</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover our complete collection of curated imports, trending goods, and rare collectibles
            </p>
          </div>

          {/* Category Grid */}
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="group cursor-pointer">
              <img
                src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
                alt="Modern e-commerce storefront display"
                className="w-full h-64 object-cover rounded-xl group-hover:shadow-xl transition-shadow duration-300"
              />
              <div className="mt-4">
                <h2 className="text-xl font-semibold text-gray-900 group-hover:text-purple-600 transition-colors">
                  Trending Electronics
                </h2>
                <p className="text-gray-600">Latest gadgets and tech accessories</p>
              </div>
            </div>
            <div className="group cursor-pointer">
              <img
                src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
                alt="Curated lifestyle products in retail setting"
                className="w-full h-64 object-cover rounded-xl group-hover:shadow-xl transition-shadow duration-300"
              />
              <div className="mt-4">
                <h2 className="text-xl font-semibold text-gray-900 group-hover:text-purple-600 transition-colors">
                  Lifestyle & Fashion
                </h2>
                <p className="text-gray-600">Curated fashion and lifestyle imports</p>
              </div>
            </div>
            <div className="group cursor-pointer">
              <img
                src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
                alt="Rare collectible items organized display"
                className="w-full h-64 object-cover rounded-xl group-hover:shadow-xl transition-shadow duration-300"
              />
              <div className="mt-4">
                <h2 className="text-xl font-semibold text-gray-900 group-hover:text-purple-600 transition-colors">
                  Rare Collectibles
                </h2>
                <p className="text-gray-600">Unique finds and vintage treasures</p>
              </div>
            </div>
          </div>

          {/* All Products */}
          <div className="bg-gray-50 rounded-xl p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">All Products</h2>
            {productsLoading ? (
              <div className="grid md:grid-cols-4 gap-6">
                {[...Array(8)].map((_, i) => (
                  <Card key={i}>
                    <Skeleton className="h-40 w-full" />
                    <CardContent className="p-4">
                      <Skeleton className="h-5 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-6 w-20" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid md:grid-cols-4 gap-6">
                {products?.map((product: any) => (
                  <Card key={product.id} className="bg-white card-hover">
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                      className="w-full h-40 object-cover"
                    />
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-semibold text-gray-900 text-sm">{product.name}</h3>
                        <Badge variant="secondary" className="text-xs">{product.category}</Badge>
                      </div>
                      <p className="text-gray-600 text-sm mb-2 line-clamp-2">{product.description}</p>
                      <div className="flex justify-between items-center">
                        <p className="text-purple-600 font-bold">${product.price}</p>
                        {product.stockQuantity && (
                          <span className="text-xs text-gray-500">{product.stockQuantity} in stock</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {!productsLoading && (!products || products.length === 0) && (
              <div className="text-center py-12">
                <div className="text-gray-400 text-6xl mb-4">📦</div>
                <h3 className="text-xl font-semibold text-gray-700 mb-2">No Products Available</h3>
                <p className="text-gray-500">Our inventory is being updated. Please check back soon!</p>
              </div>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
