import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft, ChevronRight } from "lucide-react";


export default function Home() {
  const { data: featuredCards, isLoading: cardsLoading } = useQuery({
    queryKey: ["/api/sports-cards/featured"],
  });

  const { data: featuredProducts, isLoading: productsLoading } = useQuery({
    queryKey: ["/api/products/featured"],
  });

  const { data: bundles, isLoading: bundlesLoading } = useQuery({
    queryKey: ["/api/bundles"],
  });

  // Carousel state
  const [currentSlide, setCurrentSlide] = useState(0);
  const carouselItems = [...(featuredCards || []), ...(bundles || [])];
  
  // Placeholder carousel items with card images
  const placeholderItems = [
    {
      title: "Vintage Basketball Card",
      description: "Authentic 1990s NBA rookie card in mint condition",
      price: "150.00",
      image: "https://images.unsplash.com/photo-1546519638-68e109498ffc?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200"
    },
    {
      title: "Baseball Card Bundle",
      description: "Collection of 10 premium baseball cards from the 1980s",
      price: "85.00", 
      image: "https://images.unsplash.com/photo-1566577739112-5180d4bf9390?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200"
    },
    {
      title: "Football Card Set",
      description: "Complete set of NFL quarterback cards from championship seasons",
      price: "120.00",
      image: "https://images.unsplash.com/photo-1518611012118-696072aa579a?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200"
    },
    {
      title: "Trading Card Collection",
      description: "Mixed sports cards bundle with rare vintage finds",
      price: "200.00",
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200"
    }
  ];

  // Auto-advance carousel (slowed down to 6 seconds)
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % placeholderItems.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % placeholderItems.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + placeholderItems.length) % placeholderItems.length);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      {/* Hero Section - Mobile Optimized */}
      <section className="brand-gradient text-white mobile-section">
        <div className="max-w-6xl mx-auto mobile-container text-center">
          <div className="mb-4 sm:mb-6">
            <p className="text-sm sm:text-base md:text-lg lg:text-xl font-light opacity-95 max-w-3xl mx-auto leading-relaxed">
              Curated Imports, Trending Goods, and Rare Collectibles
            </p>
          </div>

          {/* Large Featured Cards Carousel - Mobile First */}
          <div className="mt-6 sm:mt-8 md:mt-12">
            <div className="flex justify-center">
              <div className="w-full max-w-5xl">
                <Card className="bg-white/10 backdrop-blur-sm border-white/20 relative overflow-hidden">
                  <CardContent className="p-0">
                    <div className="flex flex-col lg:flex-row">
                      {/* Card image section */}
                      <div className="relative lg:w-2/3 min-h-[250px] sm:min-h-[300px] md:min-h-[350px] lg:min-h-[400px]">
                        <div 
                          className="absolute inset-0 bg-contain bg-center bg-no-repeat transition-all duration-500"
                          style={{ 
                            backgroundImage: `url(${placeholderItems[currentSlide]?.image})`,
                            backgroundSize: 'contain'
                          }}
                        />
                        
                        {/* Navigation buttons - Mobile optimized */}
                        <button
                          onClick={prevSlide}
                          className="absolute left-2 sm:left-3 lg:left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 rounded-full p-2 sm:p-3 transition-colors text-white"
                        >
                          <ChevronLeft className="w-4 h-4 sm:w-5 h-5 lg:w-6 lg:h-6" />
                        </button>
                        <button
                          onClick={nextSlide}
                          className="absolute right-2 sm:right-3 lg:right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 rounded-full p-2 sm:p-3 transition-colors text-white"
                        >
                          <ChevronRight className="w-4 h-4 sm:w-5 h-5 lg:w-6 lg:h-6" />
                        </button>
                        
                        {/* Dots indicator - Mobile optimized */}
                        <div className="absolute top-2 sm:top-3 lg:top-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                          {placeholderItems.map((_, index) => (
                            <button
                              key={index}
                              onClick={() => setCurrentSlide(index)}
                              className={`w-2 h-2 sm:w-3 sm:h-3 rounded-full transition-colors ${
                                index === currentSlide ? 'bg-white' : 'bg-white/50'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      
                      {/* Information panel with enhanced FEATURED CARDS title */}
                      <div className="lg:w-1/3 p-4 sm:p-6 lg:p-8 flex flex-col justify-center text-center text-white">
                        {/* Enhanced Featured Cards Title */}
                        <div className="mb-4 sm:mb-6">
                          <h2 className="text-lg sm:text-xl lg:text-2xl xl:text-3xl font-black tracking-wider text-yellow-300 drop-shadow-lg">
                            FEATURED
                          </h2>
                          <h2 className="text-lg sm:text-xl lg:text-2xl xl:text-3xl font-black tracking-wider text-yellow-300 drop-shadow-lg -mt-1">
                            CARDS
                          </h2>
                          <div className="w-12 sm:w-16 lg:w-20 h-0.5 bg-yellow-300 mx-auto mt-2"></div>
                        </div>
                        
                        <div className="text-2xl sm:text-3xl lg:text-4xl mb-3 sm:mb-4">🏀</div>
                        <h3 className="text-sm sm:text-base lg:text-lg xl:text-xl font-bold mb-3 sm:mb-4 leading-tight">
                          {placeholderItems[currentSlide]?.title}
                        </h3>
                        <p className="text-xs sm:text-sm lg:text-base opacity-90 mb-4 sm:mb-6 leading-relaxed">
                          {placeholderItems[currentSlide]?.description}
                        </p>
                        <div className="text-xl sm:text-2xl lg:text-3xl font-bold text-yellow-300 mb-3 sm:mb-4">
                          ${placeholderItems[currentSlide]?.price}
                        </div>
                        <Button className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold text-xs sm:text-sm lg:text-base py-2 sm:py-3 px-4 sm:px-6">
                          View Details
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
            
            {/* 2 Ways to Buy Section */}
            <div className="mt-6 sm:mt-8 lg:mt-12">
              <div className="text-center mb-4 sm:mb-6">
                <h2 className="text-lg sm:text-xl lg:text-2xl font-black text-black mb-2">2 WAYS TO BUY</h2>
                <div className="w-16 sm:w-20 lg:w-24 h-0.5 bg-black mx-auto"></div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 mobile-gap">
                <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                  <CardContent className="p-4 sm:p-5 lg:p-6 text-center">
                    <div className="mb-3 sm:mb-4 flex justify-center">
                      <svg width="32" height="32" viewBox="0 0 32 32" className="sm:w-12 sm:h-12">
                        <circle cx="16" cy="16" r="14" fill="#ff6b35" stroke="#000" stroke-width="1"/>
                        <path d="M8 12 Q16 8 24 12 Q20 20 16 24 Q12 20 8 12" fill="#000"/>
                      </svg>
                    </div>
                    <h3 className="text-sm sm:text-base lg:text-lg font-semibold mb-2 sm:mb-3">Sports Cards Vault</h3>
                    <p className="opacity-90 text-xs sm:text-sm leading-relaxed mb-4">
                      Authentic vintage NBA, NFL, MLB cards from the owner's personal collection
                    </p>
                    <Button className="bg-green-500 hover:bg-green-600 text-white font-semibold text-xs sm:text-sm px-4 py-2">
                      BUY
                    </Button>
                  </CardContent>
                </Card>
                
                <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                  <CardContent className="p-4 sm:p-5 lg:p-6 text-center">
                    <div className="mb-3 sm:mb-4 flex justify-center">
                      <svg width="32" height="32" viewBox="0 0 32 32" className="sm:w-12 sm:h-12">
                        <rect width="32" height="32" fill="#e53238" rx="4"/>
                        <text x="16" y="12" text-anchor="middle" fill="white" font-size="8" font-weight="bold">eBay</text>
                        <circle cx="8" cy="20" r="3" fill="#0064d2"/>
                        <circle cx="16" cy="20" r="3" fill="#f5af02"/>
                        <circle cx="24" cy="20" r="3" fill="#86b817"/>
                      </svg>
                    </div>
                    <h3 className="text-sm sm:text-base lg:text-lg font-semibold mb-2 sm:mb-3">eBay Auctions</h3>
                    <p className="opacity-90 text-xs sm:text-sm leading-relaxed mb-4">
                      Bid on rare cards and exclusive items through our eBay store auctions
                    </p>
                    <Button className="bg-blue-500 hover:bg-blue-600 text-white font-semibold text-xs sm:text-sm px-4 py-2">
                      BID
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MARKETPLACE Section - Mobile Optimized */}
      <section className="mobile-section bg-gray-100">
        <div className="max-w-6xl mx-auto mobile-container">
          <div className="text-center mb-6 sm:mb-8 lg:mb-12">
            <h2 className="text-lg sm:text-xl lg:text-2xl xl:text-3xl font-black text-black mb-2 sm:mb-4">MARKETPLACE</h2>
            <div className="w-20 sm:w-24 lg:w-28 h-0.5 bg-black mx-auto mb-4"></div>
            <h3 className="text-base sm:text-lg lg:text-xl font-bold text-gray-900 mb-2 sm:mb-4">Trending Products</h3>
            <p className="text-xs sm:text-sm lg:text-base text-gray-600 max-w-2xl mx-auto">
              Discover our latest curated imports and trending goods
            </p>
          </div>

          {productsLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 mobile-gap">
              {[...Array(4)].map((_, i) => (
                <Card key={i}>
                  <Skeleton className="h-28 sm:h-32 lg:h-40 w-full" />
                  <CardContent className="p-2 sm:p-3 lg:p-4">
                    <Skeleton className="h-3 sm:h-4 lg:h-5 w-3/4 mb-2" />
                    <Skeleton className="h-4 sm:h-5 lg:h-6 w-16 sm:w-20" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 mobile-gap">
              {featuredProducts?.map((product: any) => (
                <Card key={product.id} className="card-hover">
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="w-full h-28 sm:h-32 lg:h-40 object-cover"
                  />
                  <CardContent className="p-2 sm:p-3 lg:p-4">
                    <h4 className="text-xs sm:text-sm lg:text-base font-semibold text-gray-900 mb-1 sm:mb-2 leading-tight">{product.name}</h4>
                    <p className="text-sm sm:text-base lg:text-lg text-purple-600 font-bold">${product.price}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          <div className="text-center mt-6 sm:mt-8 lg:mt-12">
            <Link href="/shop-all">
              <Button size="lg" className="brand-gradient text-white text-xs sm:text-sm lg:text-base py-2 sm:py-3 px-4 sm:px-6">
                Browse All Products
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
