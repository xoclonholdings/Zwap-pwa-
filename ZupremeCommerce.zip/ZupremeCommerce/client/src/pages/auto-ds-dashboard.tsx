import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { RefreshCw, Download, DollarSign, BarChart3, Headphones, Settings, ExternalLink } from "lucide-react";

export default function AutoDSDashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/autods/stats"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const syncProductsMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/autods/sync-products"),
    onSuccess: () => {
      toast({
        title: "Sync Started",
        description: "Product synchronization has been initiated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/autods/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Sync Failed",
        description: error.message || "Failed to start product sync.",
        variant: "destructive",
      });
    },
  });

  const handleSyncProducts = () => {
    syncProductsMutation.mutate();
  };

  const formatLastSync = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} minutes ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} hours ago`;
    return `${Math.floor(diffHours / 24)} days ago`;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center mb-16">
            <Skeleton className="h-10 w-64 mx-auto mb-4" />
            <Skeleton className="h-6 w-96 mx-auto" />
          </div>
          <div className="grid md:grid-cols-4 gap-6 mb-12">
            {[...Array(4)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6 text-center">
                  <Skeleton className="h-8 w-16 mx-auto mb-2" />
                  <Skeleton className="h-4 w-20 mx-auto" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              <span className="brand-text-gradient">Auto DS Integration Dashboard</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Automated dropshipping with 24/7 price monitoring, order fulfillment, and inventory sync across all platforms
            </p>
          </div>

          {/* Dashboard Stats */}
          <div className="grid md:grid-cols-4 gap-6 mb-12">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">
                  {stats?.activeProducts?.toLocaleString() || 0}
                </div>
                <div className="text-gray-600">Active Products</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">{stats?.ordersToday || 0}</div>
                <div className="text-gray-600">Orders Today</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">{stats?.automationRate || 0}%</div>
                <div className="text-gray-600">Automation Rate</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-orange-600 mb-2">
                  ${(stats?.monthlyRevenue / 1000).toFixed(1)}K
                </div>
                <div className="text-gray-600">Monthly Revenue</div>
              </CardContent>
            </Card>
          </div>

          {/* Integration Panels */}
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {/* Auto DS Panel */}
            <Card>
              <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl">AutoDS Platform</CardTitle>
                    <p className="opacity-90">Connected & Active</p>
                  </div>
                  <div className="text-3xl opacity-80">🤖</div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">API Status</span>
                    <Badge className="bg-green-100 text-green-800">
                      ✓ Connected
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Last Sync</span>
                    <span className="text-gray-900 font-medium">
                      {stats?.lastSync ? formatLastSync(stats.lastSync) : "Never"}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Supplier Sources</span>
                    <span className="text-gray-900 font-medium text-sm">
                      {stats?.suppliers?.join(", ") || "None"}
                    </span>
                  </div>
                </div>
                <div className="mt-6 flex gap-3">
                  <Button
                    onClick={handleSyncProducts}
                    disabled={syncProductsMutation.isPending}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                  >
                    {syncProductsMutation.isPending ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <RefreshCw className="w-4 h-4 mr-2" />
                    )}
                    Sync Products
                  </Button>
                  <Button variant="outline" className="gap-2">
                    <Settings className="w-4 h-4" />
                    Settings
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* eBay Integration Panel */}
            <Card>
              <CardHeader className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white rounded-t-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl">eBay Store Sync</CardTitle>
                    <p className="opacity-90">Real-time Integration</p>
                  </div>
                  <div className="text-3xl opacity-80">🏪</div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Connection Status</span>
                    <Badge className="bg-green-100 text-green-800">
                      ✓ Active
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Active Listings</span>
                    <span className="text-gray-900 font-medium">{stats?.ebayActiveListings || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Pending Orders</span>
                    <span className="text-gray-900 font-medium">{stats?.ebayPendingOrders || 0}</span>
                  </div>
                </div>
                <div className="mt-6 flex gap-3">
                  <Button className="flex-1 bg-yellow-600 hover:bg-yellow-700">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Update Listings
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => window.open("https://ebay.com/usr/zupreme-imports", "_blank")}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View Store
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Automation Features */}
          <Card className="mb-12">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Automation Features</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <RefreshCw className="text-purple-600 w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">24/7 Price Monitoring</h3>
                  <p className="text-gray-600">
                    Automatic price adjustments based on competitor analysis and market trends
                  </p>
                </div>
                <div className="text-center">
                  <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Download className="text-green-600 w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Order Fulfillment</h3>
                  <p className="text-gray-600">
                    Automated order processing with tracking number updates across all platforms
                  </p>
                </div>
                <div className="text-center">
                  <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <BarChart3 className="text-blue-600 w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Analytics & Optimization</h3>
                  <p className="text-gray-600">
                    Real-time performance tracking with AI-powered product recommendations
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <div className="text-center">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Quick Actions</h2>
            <div className="flex flex-wrap justify-center gap-4">
              <Button className="brand-gradient text-white gap-2">
                <Download className="w-4 h-4" />
                Import Products
              </Button>
              <Button className="bg-green-600 hover:bg-green-700 text-white gap-2">
                <DollarSign className="w-4 h-4" />
                Bulk Price Update
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white gap-2">
                <BarChart3 className="w-4 h-4" />
                Generate Reports
              </Button>
              <Button className="bg-gray-600 hover:bg-gray-700 text-white gap-2">
                <Headphones className="w-4 h-4" />
                Contact Support
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
