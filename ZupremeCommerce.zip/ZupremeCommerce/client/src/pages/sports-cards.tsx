import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function SportsCards() {
  const { toast } = useToast();
  const [selectedBundle, setSelectedBundle] = useState<any>(null);

  const { data: sportsCards, isLoading: cardsLoading } = useQuery({
    queryKey: ["/api/sports-cards"],
  });

  const { data: bundles, isLoading: bundlesLoading } = useQuery({
    queryKey: ["/api/bundles"],
  });

  const handleBuyBundle = (bundle: any) => {
    setSelectedBundle(bundle);
    // Navigate to checkout with bundle info
    const checkoutUrl = `/checkout?type=bundle&id=${bundle.id}&amount=${bundle.price}&name=${encodeURIComponent(bundle.name)}`;
    window.location.href = checkoutUrl;
  };

  const handleMysteryPack = () => {
    const checkoutUrl = `/checkout?type=mystery&amount=10&name=${encodeURIComponent("Mystery Pack")}`;
    window.location.href = checkoutUrl;
  };

  const handleEbayRedirect = (url: string) => {
    window.open(url, "_blank");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      {/* Hero Section */}
      <section className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              <span className="brand-text-gradient">Zupreme Imports Vault Collection</span>
            </h1>
            <p className="text-xl text-gray-600 mb-2">Sports Cards</p>
          </div>

          {/* Featured Cards */}
          <div className="mb-16">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Featured Cards</h2>
              <p className="text-lg text-gray-500 max-w-3xl mx-auto">
                Authentic vintage NBA, NFL & MLB cards – direct from the owner's vault. Each card verified for authenticity and condition.
              </p>
            </div>
            {cardsLoading ? (
              <div className="grid md:grid-cols-3 gap-8">
                {[...Array(3)].map((_, i) => (
                  <Card key={i}>
                    <Skeleton className="h-48 w-full" />
                    <CardContent className="p-6">
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-full mb-4" />
                      <div className="flex justify-between items-center">
                        <Skeleton className="h-8 w-20" />
                        <Skeleton className="h-10 w-24" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid md:grid-cols-3 gap-8">
                {sportsCards?.map((card: any) => (
                  <Card key={card.id} className="card-hover">
                    <img
                      src={card.imageUrl}
                      alt={card.title}
                      className="w-full h-48 object-cover"
                    />
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-xl font-semibold text-gray-900">{card.title}</h3>
                        <Badge variant="secondary">{card.category}</Badge>
                      </div>
                      <p className="text-gray-600 mb-2">{card.description}</p>
                      <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
                        <span>Year: {card.year}</span>
                        <span>Condition: {card.condition}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-2xl font-bold text-purple-600">${card.price}</span>
                        <Button
                          onClick={() => handleEbayRedirect(card.ebayListingUrl)}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          Bid on eBay
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Direct Bundles */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">Direct Buy Bundles</h2>
            {bundlesLoading ? (
              <div className="grid md:grid-cols-2 gap-8">
                {[...Array(2)].map((_, i) => (
                  <Card key={i}>
                    <CardContent className="p-8">
                      <div className="flex items-center mb-4">
                        <Skeleton className="w-20 h-20 rounded-lg mr-4" />
                        <div className="flex-1">
                          <Skeleton className="h-6 w-3/4 mb-2" />
                          <Skeleton className="h-4 w-full" />
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <Skeleton className="h-8 w-16" />
                        <Skeleton className="h-10 w-24" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-8">
                {bundles?.map((bundle: any, index: number) => (
                  <Card
                    key={bundle.id}
                    className={`${
                      index === 0 ? "bg-gradient-to-br from-red-50 to-red-100 border-red-200" : 
                      "bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200"
                    }`}
                  >
                    <CardContent className="p-8">
                      <div className="flex items-center mb-4">
                        <img
                          src={bundle.imageUrl}
                          alt={bundle.name}
                          className="w-20 h-20 object-cover rounded-lg mr-4"
                        />
                        <div>
                          <h3 className="text-xl font-bold text-gray-900">{bundle.name}</h3>
                          <p className="text-gray-600">{bundle.description}</p>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-3xl font-bold text-purple-600">${bundle.price}</span>
                        <Button
                          onClick={() => handleBuyBundle(bundle)}
                          className="brand-gradient text-white hover:opacity-90"
                        >
                          Buy Now
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Mystery Pack */}
          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-xl p-8 text-center text-white mb-16">
            <h2 className="text-3xl font-bold mb-4">$10 Mystery Pack</h2>
            <p className="text-xl mb-6 opacity-90">
              Surprise selection from our vintage vault. Guaranteed authentic cards worth more than pack price!
            </p>
            <Button
              onClick={handleMysteryPack}
              className="bg-white text-orange-600 hover:bg-gray-100 px-8 py-3 text-lg font-bold"
            >
              Add to Cart
            </Button>
          </div>

          {/* eBay Store Callout */}
          <div className="text-center bg-gray-100 rounded-xl p-8">
            <div className="text-4xl text-gray-500 mb-4">🔗</div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Full Card Catalog Available</h2>
            <p className="text-lg text-gray-600 mb-6">
              Browse our complete vintage card inventory with active auctions and Buy It Now listings
            </p>
            <Button
              onClick={() => window.open("https://ebay.com/usr/zupreme-imports", "_blank")}
              className="bg-blue-600 text-white hover:bg-blue-700 px-8 py-3"
            >
              → Visit my eBay Store
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
