import { Link } from "wouter";
import logoImage from "@assets/IMG_2161_1752887326435.png";

export default function Footer() {
  return (
    <footer className="bg-slate-800 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1">
            <svg 
              className="h-16 mb-4" 
              width="200" 
              height="64" 
              viewBox="0 0 200 64" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <text 
                x="10" 
                y="35" 
                fontSize="28" 
                fontWeight="bold" 
                fill="white" 
                fontFamily="Arial, sans-serif"
              >
                ZUPREME
              </text>
              <text 
                x="10" 
                y="50" 
                fontSize="10" 
                fill="white" 
                fontFamily="Arial, sans-serif"
              >
                Since 2024
              </text>
              <text 
                x="110" 
                y="50" 
                fontSize="12" 
                fill="#10b981" 
                fontWeight="500" 
                fontFamily="Arial, sans-serif" 
                letterSpacing="2px"
              >
                IMPORTS
              </text>
            </svg>
            <p className="text-gray-300">
              Curated Imports, Trending Goods, and Rare Collectibles with Advanced E-commerce Automation
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-300 hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/sports-cards" className="text-gray-300 hover:text-white transition-colors">
                  Sports Cards Vault
                </Link>
              </li>
              <li>
                <Link href="/shop-all" className="text-gray-300 hover:text-white transition-colors">
                  Marketplace
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors" onClick={() => window.open('https://zwap.app', '_blank')}>
                  ZWAP!
                </a>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2">
              <li><span className="text-gray-300">eBay Auctions</span></li>
              <li><span className="text-gray-300">Sports Card Authentication</span></li>
              <li><span className="text-gray-300">24/7 Price Monitoring</span></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/contact" className="text-gray-300 hover:text-white transition-colors">
                  Contact Us
                </Link>
              </li>
              <li><span className="text-gray-300">API Documentation</span></li>
              <li><span className="text-gray-300">Training Resources</span></li>
              <li><span className="text-gray-300">Help Center</span></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2025 Zupreme Imports. All rights reserved. |{" "}
            <span className="text-gray-300 cursor-pointer hover:text-white">Privacy Policy</span> |{" "}
            <span className="text-gray-300 cursor-pointer hover:text-white">Terms of Service</span> |{" "}
            <Link href="/auto-ds-dashboard" className="text-gray-500 hover:text-gray-300 text-xs">
              Admin
            </Link>
          </p>
        </div>
      </div>
    </footer>
  );
}
