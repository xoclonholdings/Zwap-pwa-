import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import logoImage from "@assets/IMG_2161_1752887326435.png";

export default function Navigation() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { href: "/", label: "Home" },
    { href: "/sports-cards", label: "Sports Cards Vault" },
    { href: "/shop-all", label: "Shop All" },
    { href: "/contact", label: "Contact" },
  ];

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-6xl mx-auto mobile-container">
        <div className="flex justify-between items-center h-14 sm:h-16 lg:h-20">
          {/* Logo - Mobile Optimized */}
          <div className="flex items-center">
            <Link href="/">
              <img 
                src={logoImage} 
                alt="Zupreme Imports" 
                className="h-8 sm:h-10 lg:h-12 xl:h-16 cursor-pointer"
              />
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-6 xl:ml-10 flex items-baseline space-x-4 xl:space-x-8">
              {navItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <a
                    className={`px-3 xl:px-4 py-2 xl:py-3 text-sm xl:text-base font-semibold transition-colors ${
                      location === item.href
                        ? "text-purple-600"
                        : "text-gray-900 hover:text-purple-600"
                    }`}
                  >
                    {item.label}
                  </a>
                </Link>
              ))}
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2"
            >
              {isMobileMenuOpen ? <X className="h-5 w-5 sm:h-6 sm:w-6" /> : <Menu className="h-5 w-5 sm:h-6 sm:w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 sm:px-3 pt-2 pb-3 space-y-1 bg-white shadow-lg border-t">
              {navItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <a
                    className={`block px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base font-medium transition-colors rounded-md ${
                      location === item.href
                        ? "text-purple-600 bg-purple-50"
                        : "text-gray-900 hover:text-purple-600 hover:bg-gray-50"
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.label}
                  </a>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
