#!/bin/bash

echo "🚀 Building Zupreme Imports for production deployment..."

# Create deployment directory
mkdir -p dist

# Install dependencies (if needed)
echo "📦 Installing dependencies..."
npm ci --production=false

# Build the client application
echo "🏗️ Building client application..."
npm run build

# Build the server application
echo "🔧 Building server application..."
npx esbuild server/index.ts --bundle --platform=node --target=node18 --outfile=dist/server.js --external:pg --external:express --external:ws

# Copy necessary files
echo "📋 Copying deployment files..."
cp package.json dist/
cp package-lock.json dist/
cp -r docs dist/
cp README.md dist/ 2>/dev/null || echo "README.md not found, skipping..."

# Create production package.json
echo "📄 Creating production package.json..."
cat > dist/package.json << 'EOF'
{
  "name": "zupreme-imports",
  "version": "1.0.0",
  "description": "Premium vintage sports cards e-commerce platform",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "postinstall": "npm install --production"
  },
  "dependencies": {
    "@neondatabase/serverless": "^0.9.0",
    "express": "^4.18.2",
    "express-session": "^1.17.3",
    "connect-pg-simple": "^9.0.1",
    "passport": "^0.7.0",
    "passport-local": "^1.0.0",
    "drizzle-orm": "^0.29.0",
    "zod": "^3.22.4",
    "stripe": "^14.0.0",
    "ws": "^8.14.2"
  },
  "engines": {
    "node": ">=18.0.0"
  }
}
EOF

# Create deployment instructions
echo "📝 Creating deployment instructions..."
cat > dist/DEPLOYMENT.md << 'EOF'
# Zupreme Imports Deployment Guide

## Quick Start

1. **Upload Files**: Extract and upload all files to your web host
2. **Install Dependencies**: Run `npm install` in the root directory
3. **Set Environment Variables**: Configure required environment variables
4. **Start Server**: Run `npm start`

## Environment Variables

### Required Variables
```bash
NODE_ENV=production
PORT=3000
SESSION_SECRET=your-secure-session-secret-here
```

### Optional Variables (for full functionality)
```bash
# Database (if using PostgreSQL)
DATABASE_URL=postgresql://user:password@host:port/database

# Payment Processing
STRIPE_SECRET_KEY=sk_live_...
VITE_STRIPE_PUBLIC_KEY=pk_live_...

# Marketplace Integrations
SHOPIFY_API_KEY=your-shopify-api-key
EBAY_API_KEY=your-ebay-api-key
AUTODS_API_KEY=your-autods-api-key
```

## Deployment Steps

### 1. File Upload
- Upload all files to your web host's public directory
- Ensure file permissions are set correctly (755 for directories, 644 for files)

### 2. Install Dependencies
```bash
cd /path/to/your/site
npm install
```

### 3. Configure Environment
- Create a `.env` file with your environment variables
- Or set environment variables through your hosting control panel

### 4. Start the Application
```bash
npm start
```

## Web Host Compatibility

### Shared Hosting
- Requires Node.js support (18+)
- May need to configure port settings
- Some features may require VPS hosting

### VPS/Dedicated Hosting
- Full compatibility
- Can use process managers like PM2
- Recommended for production use

### Cloud Hosting (Recommended)
- Heroku, DigitalOcean App Platform, Railway
- Automatic scaling and deployment
- Built-in environment variable management

## Default Credentials

**Admin Access:**
- URL: `/admin/login`
- Username: `admin`
- Password: `zupreme2025`

**⚠️ Important:** Change the default password immediately after deployment!

## Troubleshooting

### Common Issues
1. **Port conflicts**: Ensure PORT environment variable is set correctly
2. **Missing dependencies**: Run `npm install` if modules are missing
3. **Permission errors**: Check file and directory permissions
4. **Environment variables**: Verify all required variables are set

### Support
- Documentation: `/docs/admin-setup-guide.md`
- Configuration: `/docs/feature-configuration.md`
- Admin panel: `/admin/dashboard`

## Performance Optimization

### For Production
1. Enable gzip compression on your server
2. Set up a CDN for static assets
3. Configure caching headers
4. Monitor server resources

### Scaling
- Use a load balancer for multiple instances
- Consider database connection pooling
- Implement Redis for session storage
- Set up monitoring and alerts
EOF

# Create .htaccess for Apache servers
echo "🔧 Creating Apache configuration..."
cat > dist/.htaccess << 'EOF'
# Zupreme Imports Apache Configuration

# Enable compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml
    AddOutputFilterByType DEFLATE application/rss+xml
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/x-javascript
</IfModule>

# Cache static assets
<IfModule mod_expires.c>
    ExpiresActive on
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
</IfModule>

# Security headers
<IfModule mod_headers.c>
    Header always set X-Content-Type-Options nosniff
    Header always set X-Frame-Options DENY
    Header always set X-XSS-Protection "1; mode=block"
</IfModule>

# Redirect all requests to Node.js server (if using reverse proxy)
# RewriteEngine On
# RewriteCond %{REQUEST_FILENAME} !-f
# RewriteCond %{REQUEST_FILENAME} !-d
# RewriteRule ^(.*)$ http://localhost:3000/$1 [P,L]
EOF

echo "✅ Build completed successfully!"
echo ""
echo "📦 Deployment package created in 'dist' directory"
echo "📁 Package contents:"
echo "   - server.js (bundled server application)"
echo "   - client/ (built frontend assets)"
echo "   - package.json (production dependencies)"
echo "   - docs/ (documentation)"
echo "   - DEPLOYMENT.md (deployment instructions)"
echo "   - .htaccess (Apache configuration)"
echo ""
echo "🚀 Ready for deployment to your web host!"
echo "📖 See dist/DEPLOYMENT.md for detailed instructions"