#!/bin/bash

echo "📦 Creating deployment package for web hosting..."

# Create export directory
rm -rf webhost-export
mkdir -p webhost-export

# Build the application
echo "🏗️ Building application..."
npm run build

# Copy built files
echo "📋 Copying files..."
cp -r dist/* webhost-export/
cp -r docs webhost-export/
cp package.json webhost-export/
cp package-lock.json webhost-export/

# Create simplified package.json for hosting
cat > webhost-export/package.json << 'EOF'
{
  "name": "zupreme-imports",
  "version": "1.0.0",
  "type": "module",
  "main": "index.js",
  "scripts": {
    "start": "node index.js"
  },
  "dependencies": {
    "@neondatabase/serverless": "^0.10.4",
    "express": "^4.18.2",
    "express-session": "^1.17.3",
    "connect-pg-simple": "^9.0.1",
    "passport": "^0.7.0",
    "passport-local": "^1.0.0",
    "drizzle-orm": "^0.29.0",
    "zod": "^3.22.4",
    "stripe": "^14.0.0",
    "ws": "^8.14.2"
  },
  "engines": {
    "node": ">=18.0.0"
  }
}
EOF

# Create environment template
cat > webhost-export/.env.example << 'EOF'
# Zupreme Imports Environment Configuration

# Basic Settings
NODE_ENV=production
PORT=3000
SESSION_SECRET=change-this-to-a-secure-secret

# Database (Optional - uses in-memory storage by default)
# DATABASE_URL=postgresql://user:password@host:port/database

# Payment Processing (Optional)
# STRIPE_SECRET_KEY=sk_live_...
# VITE_STRIPE_PUBLIC_KEY=pk_live_...

# Marketplace Integrations (Optional)
# SHOPIFY_API_KEY=your-shopify-api-key
# EBAY_API_KEY=your-ebay-api-key
# AUTODS_API_KEY=your-autods-api-key
EOF

# Create README for deployment
cat > webhost-export/README.md << 'EOF'
# Zupreme Imports - Web Host Deployment

## Quick Deployment Steps

1. **Upload Files**: Upload all files to your web host
2. **Install Dependencies**: Run `npm install`
3. **Configure Environment**: Copy `.env.example` to `.env` and configure
4. **Start Application**: Run `npm start`

## Admin Access
- URL: `/admin/login`
- Username: `admin`
- Password: `zupreme2025`

⚠️ **Change the default password immediately!**

## Features Included
- ✅ Complete e-commerce store
- ✅ Sports cards vault
- ✅ Admin dashboard
- ✅ Product management
- ✅ Marketplace integrations (Shopify, eBay)
- ✅ Configuration system
- ✅ System diagnostics
- ✅ Data export/import

## Support
See `docs/admin-setup-guide.md` for detailed configuration instructions.
EOF

# Create .htaccess for Apache
cat > webhost-export/.htaccess << 'EOF'
# Apache configuration for Zupreme Imports
RewriteEngine On

# Handle React Router
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.html [L]

# Security headers
Header always set X-Content-Type-Options nosniff
Header always set X-Frame-Options DENY
Header always set X-XSS-Protection "1; mode=block"
EOF

# Create deployment info
cat > webhost-export/DEPLOYMENT-INFO.txt << 'EOF'
Zupreme Imports - Deployment Package
===================================

Package Contents:
- index.js (main server file)
- client/ (frontend assets)
- docs/ (documentation)
- package.json (dependencies)
- .env.example (environment template)
- README.md (quick start guide)

Default Admin Credentials:
- Username: admin
- Password: zupreme2025

Important: Change admin password after deployment!

For detailed setup instructions, see:
- README.md (quick start)
- docs/admin-setup-guide.md (comprehensive guide)
- docs/feature-configuration.md (feature settings)
- docs/deployment-checklist.md (production checklist)
EOF

echo "✅ Export completed!"
echo ""
echo "📁 Deployment package created in 'webhost-export' directory"
echo "📦 Package size: $(du -sh webhost-export | cut -f1)"
echo ""
echo "🚀 Ready to upload to your web host!"
echo "📖 See webhost-export/README.md for deployment instructions"
echo ""
echo "💡 To create a ZIP file:"
echo "   cd webhost-export && zip -r ../zupreme-imports-deployment.zip ."