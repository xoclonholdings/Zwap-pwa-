# Zupreme Imports - E-commerce Platform

## Overview

Zupreme Imports is a modern e-commerce platform specializing in curated imports, trending goods, and rare collectibles, with a dedicated focus on sports cards. The application features advanced e-commerce automation through AutoDS integration and Stripe payment processing.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Components**: Shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom brand colors and design system
- **State Management**: TanStack Query (React Query) for server state
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API with structured route handling
- **Development**: Hot module replacement with Vite middleware integration

### Database & ORM
- **Database**: PostgreSQL (configured for Neon Database)
- **ORM**: Drizzle ORM for type-safe database operations
- **Migrations**: Drizzle Kit for schema management
- **Connection**: Serverless-compatible with connection pooling

## Key Components

### Core Entities
1. **Sports Cards**: Featured collectibles with eBay integration
2. **Products**: General merchandise with AutoDS automation
3. **Bundles**: Curated product collections
4. **Orders**: Purchase tracking and fulfillment
5. **Users**: Customer management with Stripe integration
6. **Contact Submissions**: Customer inquiry handling

### Page Structure
- **Home**: Landing page with featured content and brand showcase
- **Sports Cards Vault**: Dedicated sports cards marketplace with eBay redirect logic
- **AutoDS Dashboard**: Business automation monitoring and product sync
- **Shop All**: Complete product catalog browsing
- **Contact**: Customer communication portal
- **Checkout**: Stripe-powered payment processing
- **Admin Login**: Secure authentication portal for administrators
- **Admin Dashboard**: Comprehensive management interface with Shopify and eBay integration

### Storage Layer
- **Interface-based Design**: IStorage interface for flexible data access
- **Memory Storage**: Development implementation for rapid prototyping
- **Database Storage**: Production-ready PostgreSQL integration
- **Type Safety**: Full TypeScript integration with Zod validation
- **Admin Operations**: CRUD functionality for product management
- **Marketplace Sync**: Integration endpoints for Shopify and eBay

## Data Flow

### E-commerce Flow
1. Customer browses products/sports cards
2. Direct purchases through Stripe checkout
3. eBay redirection for auction items
4. Order processing and fulfillment tracking

### AutoDS Integration Flow
1. Product synchronization from AutoDS
2. Inventory management automation
3. Real-time dashboard monitoring
4. Performance analytics tracking

### Sports Cards Funnel
1. Featured cards displayed on vault page
2. Direct purchase options for premium items
3. eBay store redirection for full inventory
4. Bundle packages for immediate checkout

## External Dependencies

### Payment Processing
- **Stripe**: Complete payment infrastructure
- **Stripe Elements**: Secure payment form components
- **Webhook Handling**: Payment confirmation and order updates

### E-commerce Automation
- **AutoDS**: Product sourcing and inventory management
- **Shopify Integration**: Marketplace synchronization for all products
- **eBay Integration**: Sports cards auction platform with automated listing creation
- **Real-time Sync**: Automated product updates across all platforms
- **Admin Management**: Centralized control for marketplace operations

### UI/UX Libraries
- **Radix UI**: Accessible component primitives
- **Lucide Icons**: Consistent iconography
- **React Hook Form**: Form validation and handling
- **Date-fns**: Date manipulation utilities

### Development Tools
- **Replit Integration**: Development environment optimization
- **ESBuild**: Fast production bundling
- **PostCSS**: CSS processing pipeline

## Deployment Strategy

### Development Environment
- **Hot Reloading**: Vite-powered development server
- **Type Checking**: Real-time TypeScript validation
- **Database**: Local development with migration support

### Production Build
- **Client Bundle**: Optimized React application
- **Server Bundle**: Express.js with ESBuild compilation
- **Static Assets**: Efficient asset optimization and caching
- **Environment Variables**: Secure configuration management

### Database Deployment
- **Migration Strategy**: Drizzle migrations for schema updates
- **Connection Pooling**: Optimized for serverless environments
- **Backup Strategy**: Automated PostgreSQL backups

## Recent Updates

### Comprehensive Configuration System (January 2025)
- **Feature Configuration**: Complete configurable system with feature flags and runtime settings
- **Store Settings Dashboard**: 6 categories including Store Information, Payment & Shipping, Automation, SEO & Marketing, System Maintenance, and Security
- **Configuration Management**: Real-time settings through admin interface with database persistence
- **Feature Toggles**: Enable/disable functionality without code changes

### System Diagnostics & Optimization (January 2025)
- **Health Monitoring**: Comprehensive system diagnostics checking database, storage, memory, API endpoints, integrations, and security
- **Performance Optimization**: Automated storage optimization, data compression, and cleanup processes
- **Data Export System**: Complete export functionality for products, sports cards, configuration, and system reports
- **Admin Documentation**: Comprehensive setup guide, feature configuration manual, and deployment checklist

### Admin System Implementation (January 2025)
- **Admin Authentication**: Secure login system with session management
- **Product Management**: Full CRUD operations for inventory control
- **Shopify Integration**: Automated marketplace synchronization for all products
- **eBay Integration**: Sports cards auction listing with automated creation
- **Dashboard Analytics**: Real-time statistics and performance monitoring
- **Marketplace Sync**: Centralized control for multi-platform operations

### Admin Credentials
- **Username**: admin
- **Password**: zupreme2025
- **Access**: `/admin/login` for secure authentication portal

The application is designed as a monorepo with clear separation between client, server, and shared code, enabling efficient development and deployment workflows while maintaining type safety throughout the stack. The new admin system provides comprehensive marketplace management with Shopify and eBay integration for automated business operations.