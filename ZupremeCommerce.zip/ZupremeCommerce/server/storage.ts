import { 
  users, sportsCards, products, bundles, orders, contactSubmissions,
  type User, type InsertUser, type SportsCard, type InsertSportsCard,
  type Product, type InsertProduct, type Bundle, type InsertBundle,
  type Order, type InsertOrder, type ContactSubmission, type InsertContact
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStripeInfo(userId: number, customerId: string, subscriptionId: string): Promise<User>;

  // Sports Cards
  getAllSportsCards(): Promise<SportsCard[]>;
  getSportsCard(id: number): Promise<SportsCard | undefined>;
  createSportsCard(card: InsertSportsCard): Promise<SportsCard>;
  getFeaturedSportsCards(): Promise<SportsCard[]>;

  // Products
  getAllProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, updates: Partial<Product>): Promise<Product>;
  deleteProduct(id: string): Promise<void>;
  getFeaturedProducts(): Promise<Product[]>;

  // Bundles
  getAllBundles(): Promise<Bundle[]>;
  getBundle(id: number): Promise<Bundle | undefined>;
  createBundle(bundle: InsertBundle): Promise<Bundle>;

  // Orders
  createOrder(order: InsertOrder): Promise<Order>;
  getOrder(id: number): Promise<Order | undefined>;
  updateOrderStatus(id: number, status: string): Promise<Order>;

  // Contact
  createContactSubmission(contact: InsertContact): Promise<ContactSubmission>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private sportsCards: Map<number, SportsCard>;
  private products: Map<number, Product>;
  private bundles: Map<number, Bundle>;
  private orders: Map<number, Order>;
  private contactSubmissions: Map<number, ContactSubmission>;
  private currentUserId: number;
  private currentSportsCardId: number;
  private currentProductId: number;
  private currentBundleId: number;
  private currentOrderId: number;
  private currentContactId: number;

  constructor() {
    this.users = new Map();
    this.sportsCards = new Map();
    this.products = new Map();
    this.bundles = new Map();
    this.orders = new Map();
    this.contactSubmissions = new Map();
    this.currentUserId = 1;
    this.currentSportsCardId = 1;
    this.currentProductId = 1;
    this.currentBundleId = 1;
    this.currentOrderId = 1;
    this.currentContactId = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Featured Sports Cards
    const featuredCards: Omit<SportsCard, 'id'>[] = [
      {
        title: "1986 Fleer Michael Jordan Rookie",
        description: "Near mint condition rookie card from the legendary 1986 Fleer set. Professionally graded PSA 8.",
        price: "2450.00",
        currentBid: "2450.00",
        imageUrl: "https://images.unsplash.com/photo-1546026423-cc4642628d2b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        category: "NBA",
        year: 1986,
        condition: "Near Mint",
        ebayListingUrl: "https://ebay.com/itm/jordan-rookie",
        isActive: true,
        createdAt: new Date(),
      },
      {
        title: "1957 Topps Johnny Unitas",
        description: "Exceptional vintage football card featuring the Hall of Fame quarterback. Excellent condition with sharp corners.",
        price: "875.00",
        currentBid: "875.00",
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        category: "NFL",
        year: 1957,
        condition: "Excellent",
        ebayListingUrl: "https://ebay.com/itm/unitas-vintage",
        isActive: true,
        createdAt: new Date(),
      },
      {
        title: "1952 Topps Mickey Mantle",
        description: "Iconic rookie card from the most celebrated set in baseball card history. Good condition with natural wear.",
        price: "15200.00",
        currentBid: "15200.00",
        imageUrl: "https://images.unsplash.com/photo-1566577739112-5180d4bf9390?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        category: "MLB",
        year: 1952,
        condition: "Good",
        ebayListingUrl: "https://ebay.com/itm/mantle-rookie",
        isActive: true,
        createdAt: new Date(),
      },
    ];

    featuredCards.forEach(card => {
      const id = this.currentSportsCardId++;
      this.sportsCards.set(id, { ...card, id });
    });

    // Bundles
    const sampleBundles: Omit<Bundle, 'id'>[] = [
      {
        name: "Chicago Bulls 90s Bundle",
        description: "Complete collection from the championship era featuring Jordan, Pippen, and Rodman cards",
        price: "25.00",
        imageUrl: "https://images.unsplash.com/photo-1578507065211-1c4e99a5fd24?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
        isActive: true,
        createdAt: new Date(),
      },
      {
        name: "NFL Quarterbacks Pack",
        description: "Legendary QBs from the 80s and 90s including Montana, Elway, and Young",
        price: "20.00",
        imageUrl: "https://images.unsplash.com/photo-1577223625816-7546f13df25d?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
        isActive: true,
        createdAt: new Date(),
      },
    ];

    sampleBundles.forEach(bundle => {
      const id = this.currentBundleId++;
      this.bundles.set(id, { ...bundle, id });
    });

    // Products
    const sampleProducts: Omit<Product, 'id'>[] = [
      {
        name: "Wireless Earbuds Pro",
        description: "High-quality wireless earbuds with noise cancellation",
        price: "89.99",
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        isActive: true,
        stockQuantity: 50,
        autodsProductId: null,
        createdAt: new Date(),
      },
      {
        name: "Designer Watch",
        description: "Elegant timepiece with premium leather strap",
        price: "245.00",
        category: "Fashion",
        imageUrl: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        isActive: true,
        stockQuantity: 25,
        autodsProductId: null,
        createdAt: new Date(),
      },
      {
        name: "Vintage Coin Set",
        description: "Rare collectible coins from the early 1900s",
        price: "125.00",
        category: "Collectibles",
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        isActive: true,
        stockQuantity: 10,
        autodsProductId: null,
        createdAt: new Date(),
      },
      {
        name: "Smart Home Device",
        description: "Voice-controlled smart speaker with home automation",
        price: "159.99",
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        isActive: true,
        stockQuantity: 75,
        autodsProductId: null,
        createdAt: new Date(),
      },
    ];

    sampleProducts.forEach(product => {
      const id = this.currentProductId++;
      this.products.set(id, { ...product, id });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      email: insertUser.email ?? null,
      stripeCustomerId: null, 
      stripeSubscriptionId: null 
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStripeInfo(userId: number, customerId: string, subscriptionId: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, stripeCustomerId: customerId, stripeSubscriptionId: subscriptionId };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async getAllSportsCards(): Promise<SportsCard[]> {
    return Array.from(this.sportsCards.values()).filter(card => card.isActive);
  }

  async getSportsCard(id: number): Promise<SportsCard | undefined> {
    return this.sportsCards.get(id);
  }

  async createSportsCard(card: InsertSportsCard): Promise<SportsCard> {
    const id = this.currentSportsCardId++;
    const newCard: SportsCard = { 
      ...card, 
      id, 
      currentBid: card.currentBid ?? null,
      imageUrl: card.imageUrl ?? null,
      year: card.year ?? null,
      condition: card.condition ?? null,
      ebayListingUrl: card.ebayListingUrl ?? null,
      isActive: card.isActive ?? null,
      createdAt: new Date() 
    };
    this.sportsCards.set(id, newCard);
    return newCard;
  }

  async getFeaturedSportsCards(): Promise<SportsCard[]> {
    return Array.from(this.sportsCards.values()).filter(card => card.isActive).slice(0, 3);
  }

  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.isActive);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const newProduct: Product = { 
      ...product, 
      id, 
      imageUrl: product.imageUrl ?? null,
      isActive: product.isActive ?? null,
      autodsProductId: product.autodsProductId ?? null,
      stockQuantity: product.stockQuantity ?? null,
      createdAt: new Date() 
    };
    this.products.set(id, newProduct);
    return newProduct;
  }

  async updateProduct(id: string, updates: Partial<Product>): Promise<Product> {
    const productId = parseInt(id);
    const existing = this.products.get(productId);
    if (!existing) throw new Error("Product not found");
    
    const updated = { ...existing, ...updates };
    this.products.set(productId, updated);
    return updated;
  }

  async deleteProduct(id: string): Promise<void> {
    const productId = parseInt(id);
    if (!this.products.has(productId)) {
      throw new Error("Product not found");
    }
    this.products.delete(productId);
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.isActive).slice(0, 4);
  }

  async getAllBundles(): Promise<Bundle[]> {
    return Array.from(this.bundles.values()).filter(bundle => bundle.isActive);
  }

  async getBundle(id: number): Promise<Bundle | undefined> {
    return this.bundles.get(id);
  }

  async createBundle(bundle: InsertBundle): Promise<Bundle> {
    const id = this.currentBundleId++;
    const newBundle: Bundle = { 
      ...bundle, 
      id, 
      imageUrl: bundle.imageUrl ?? null,
      isActive: bundle.isActive ?? null,
      createdAt: new Date() 
    };
    this.bundles.set(id, newBundle);
    return newBundle;
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const id = this.currentOrderId++;
    const newOrder: Order = { 
      ...order, 
      id, 
      status: order.status ?? "pending",
      stripePaymentIntentId: order.stripePaymentIntentId ?? null,
      createdAt: new Date() 
    };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async updateOrderStatus(id: number, status: string): Promise<Order> {
    const order = this.orders.get(id);
    if (!order) throw new Error("Order not found");
    
    const updatedOrder = { ...order, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  async createContactSubmission(contact: InsertContact): Promise<ContactSubmission> {
    const id = this.currentContactId++;
    const newContact: ContactSubmission = { ...contact, id, createdAt: new Date() };
    this.contactSubmissions.set(id, newContact);
    return newContact;
  }
}

export const storage = new MemStorage();
