import { storage } from "./storage";
import { diagnostics } from "./diagnostics";
import { optimizer } from "./optimization";

export interface ExportResult {
  type: string;
  filename: string;
  size: number;
  recordCount: number;
  format: "json" | "csv" | "xml";
  success: boolean;
  error?: string;
}

export interface ExportOptions {
  format: "json" | "csv" | "xml";
  includeInactive?: boolean;
  dateRange?: {
    start: Date;
    end: Date;
  };
  categories?: string[];
}

export class DataExporter {
  async exportAllData(): Promise<ExportResult[]> {
    const results: ExportResult[] = [];
    
    // Export products
    results.push(await this.exportProducts({ format: "json" }));
    results.push(await this.exportProducts({ format: "csv" }));
    
    // Export sports cards
    results.push(await this.exportSportsCards({ format: "json" }));
    results.push(await this.exportSportsCards({ format: "csv" }));
    
    // Export bundles
    results.push(await this.exportBundles({ format: "json" }));
    
    // Export system configuration
    results.push(await this.exportConfiguration());
    
    // Export diagnostics report
    results.push(await this.exportDiagnostics());
    
    return results;
  }

  async exportProducts(options: ExportOptions): Promise<ExportResult> {
    try {
      const products = await storage.getAllProducts();
      let filteredProducts = products;
      
      // Apply filters
      if (!options.includeInactive) {
        filteredProducts = products.filter(p => p.isActive);
      }
      
      if (options.categories && options.categories.length > 0) {
        filteredProducts = filteredProducts.filter(p => 
          options.categories!.includes(p.category || '')
        );
      }
      
      if (options.dateRange) {
        filteredProducts = filteredProducts.filter(p => {
          if (!p.createdAt) return false;
          const productDate = new Date(p.createdAt);
          return productDate >= options.dateRange!.start && productDate <= options.dateRange!.end;
        });
      }
      
      const data = this.formatData(filteredProducts, options.format);
      const filename = `products_${new Date().toISOString().split('T')[0]}.${options.format}`;
      
      return {
        type: "Products",
        filename,
        size: new Blob([data]).size,
        recordCount: filteredProducts.length,
        format: options.format,
        success: true
      };
    } catch (error) {
      return {
        type: "Products",
        filename: "",
        size: 0,
        recordCount: 0,
        format: options.format,
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }

  async exportSportsCards(options: ExportOptions): Promise<ExportResult> {
    try {
      const sportsCards = await storage.getAllSportsCards();
      let filteredCards = sportsCards;
      
      if (options.dateRange) {
        filteredCards = filteredCards.filter(c => {
          if (!c.createdAt) return false;
          const cardDate = new Date(c.createdAt);
          return cardDate >= options.dateRange!.start && cardDate <= options.dateRange!.end;
        });
      }
      
      const data = this.formatData(filteredCards, options.format);
      const filename = `sports_cards_${new Date().toISOString().split('T')[0]}.${options.format}`;
      
      return {
        type: "Sports Cards",
        filename,
        size: new Blob([data]).size,
        recordCount: filteredCards.length,
        format: options.format,
        success: true
      };
    } catch (error) {
      return {
        type: "Sports Cards",
        filename: "",
        size: 0,
        recordCount: 0,
        format: options.format,
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }

  async exportBundles(options: ExportOptions): Promise<ExportResult> {
    try {
      const bundles = await storage.getAllBundles();
      let filteredBundles = bundles;
      
      if (!options.includeInactive) {
        filteredBundles = bundles.filter(b => b.isActive);
      }
      
      const data = this.formatData(filteredBundles, options.format);
      const filename = `bundles_${new Date().toISOString().split('T')[0]}.${options.format}`;
      
      return {
        type: "Bundles",
        filename,
        size: new Blob([data]).size,
        recordCount: filteredBundles.length,
        format: options.format,
        success: true
      };
    } catch (error) {
      return {
        type: "Bundles",
        filename: "",
        size: 0,
        recordCount: 0,
        format: options.format,
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }

  async exportConfiguration(): Promise<ExportResult> {
    try {
      const config = {
        store: {
          name: "Zupreme Imports",
          description: "Premium vintage sports cards, trending imports, and rare collectibles",
          contactEmail: "support@zupremeimports.com",
          phone: "+1 (555) 123-4567"
        },
        features: {
          chatbot: true,
          sportsCardsVault: true,
          autoDsIntegration: true,
          shopifySync: true,
          ebaySync: true
        },
        integrations: {
          shopify: { enabled: true, storeUrl: "zupreme-imports.myshopify.com" },
          ebay: { enabled: true, sellerId: "zupreme_imports" },
          autods: { enabled: true }
        },
        exportDate: new Date().toISOString()
      };
      
      const data = JSON.stringify(config, null, 2);
      const filename = `configuration_${new Date().toISOString().split('T')[0]}.json`;
      
      return {
        type: "Configuration",
        filename,
        size: new Blob([data]).size,
        recordCount: Object.keys(config).length,
        format: "json",
        success: true
      };
    } catch (error) {
      return {
        type: "Configuration",
        filename: "",
        size: 0,
        recordCount: 0,
        format: "json",
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }

  async exportDiagnostics(): Promise<ExportResult> {
    try {
      const report = await diagnostics.generateReport();
      const filename = `diagnostics_${new Date().toISOString().split('T')[0]}.md`;
      
      return {
        type: "Diagnostics",
        filename,
        size: new Blob([report]).size,
        recordCount: 1,
        format: "json", // Markdown treated as text
        success: true
      };
    } catch (error) {
      return {
        type: "Diagnostics",
        filename: "",
        size: 0,
        recordCount: 0,
        format: "json",
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }

  private formatData(data: any[], format: "json" | "csv" | "xml"): string {
    switch (format) {
      case "json":
        return JSON.stringify(data, null, 2);
      
      case "csv":
        if (data.length === 0) return "";
        
        const headers = Object.keys(data[0]);
        const csvHeaders = headers.join(",");
        const csvRows = data.map(item => 
          headers.map(header => {
            const value = item[header];
            // Escape CSV values that contain commas or quotes
            if (typeof value === "string" && (value.includes(",") || value.includes('"'))) {
              return `"${value.replace(/"/g, '""')}"`;
            }
            return value || "";
          }).join(",")
        );
        
        return [csvHeaders, ...csvRows].join("\n");
      
      case "xml":
        const xmlData = data.map(item => {
          const xmlFields = Object.entries(item)
            .map(([key, value]) => `    <${key}>${this.escapeXml(String(value || ""))}</${key}>`)
            .join("\n");
          return `  <item>\n${xmlFields}\n  </item>`;
        }).join("\n");
        
        return `<?xml version="1.0" encoding="UTF-8"?>\n<data>\n${xmlData}\n</data>`;
      
      default:
        return JSON.stringify(data, null, 2);
    }
  }

  private escapeXml(unsafe: string): string {
    return unsafe.replace(/[<>&'"]/g, (c) => {
      switch (c) {
        case '<': return '&lt;';
        case '>': return '&gt;';
        case '&': return '&amp;';
        case '\'': return '&apos;';
        case '"': return '&quot;';
        default: return c;
      }
    });
  }

  async generateExportReport(): Promise<string> {
    const results = await this.exportAllData();
    const timestamp = new Date().toISOString();
    
    const totalSize = results.reduce((sum, r) => sum + r.size, 0);
    const totalRecords = results.reduce((sum, r) => sum + r.recordCount, 0);
    const successCount = results.filter(r => r.success).length;
    
    return `
# Data Export Report
Generated: ${timestamp}

## Summary
- Total Files: ${results.length}
- Successful Exports: ${successCount}
- Total Size: ${this.formatBytes(totalSize)}
- Total Records: ${totalRecords}

## Export Results
${results.map(result => `
### ${result.type}
File: ${result.filename}
Format: ${result.format.toUpperCase()}
Status: ${result.success ? 'SUCCESS' : 'FAILED'}
Size: ${this.formatBytes(result.size)}
Records: ${result.recordCount}
${result.error ? `Error: ${result.error}` : ''}
`).join('\n')}

## Deployment Checklist
- [ ] Verify all exports completed successfully
- [ ] Review system diagnostics
- [ ] Confirm marketplace integrations
- [ ] Test admin authentication
- [ ] Validate product data integrity
- [ ] Check performance metrics
- [ ] Backup configuration files
- [ ] Document any custom modifications

## Post-Deployment Steps
1. Monitor system health for 24 hours
2. Verify marketplace sync functionality
3. Test customer-facing features
4. Schedule regular optimization runs
5. Set up monitoring and alerts
`;
  }

  private formatBytes(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }
}

export const exporter = new DataExporter();