import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { insertContactSchema, insertOrderSchema } from "@shared/schema";

const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-06-30.basil",
}) : null;

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Sports Cards API
  app.get("/api/sports-cards", async (req, res) => {
    try {
      const cards = await storage.getAllSportsCards();
      res.json(cards);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching sports cards: " + error.message });
    }
  });

  app.get("/api/sports-cards/featured", async (req, res) => {
    try {
      const cards = await storage.getFeaturedSportsCards();
      res.json(cards);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching featured cards: " + error.message });
    }
  });

  // Products API
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching products: " + error.message });
    }
  });

  app.get("/api/products/featured", async (req, res) => {
    try {
      const products = await storage.getFeaturedProducts();
      res.json(products);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching featured products: " + error.message });
    }
  });

  // Bundles API
  app.get("/api/bundles", async (req, res) => {
    try {
      const bundles = await storage.getAllBundles();
      res.json(bundles);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching bundles: " + error.message });
    }
  });

  // Contact Form API
  app.post("/api/contact", async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await storage.createContactSubmission(contactData);
      res.json({ message: "Contact form submitted successfully", id: contact.id });
    } catch (error: any) {
      res.status(400).json({ message: "Error submitting contact form: " + error.message });
    }
  });

  // Stripe Payment Intent API
  app.post("/api/create-payment-intent", async (req, res) => {
    if (!stripe) {
      return res.status(500).json({ message: "Stripe not configured. Please set STRIPE_SECRET_KEY environment variable." });
    }

    try {
      const { amount, currency = "usd", customerEmail, customerName, items } = req.body;
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency,
        metadata: {
          customerEmail: customerEmail || "",
          customerName: customerName || "",
          items: JSON.stringify(items || []),
        },
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Order creation API
  app.post("/api/orders", async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(orderData);
      res.json(order);
    } catch (error: any) {
      res.status(400).json({ message: "Error creating order: " + error.message });
    }
  });

  // Auto DS Dashboard Stats API (mock data for demo)
  app.get("/api/autods/stats", async (req, res) => {
    try {
      // Mock Auto DS integration stats
      const stats = {
        activeProducts: 1247,
        ordersToday: 23,
        automationRate: 96,
        monthlyRevenue: 18500,
        lastSync: new Date(Date.now() - 2 * 60 * 1000).toISOString(), // 2 minutes ago
        suppliers: ["Amazon", "Walmart", "AliExpress"],
        ebayActiveListings: 156,
        ebayPendingOrders: 7,
      };
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching Auto DS stats: " + error.message });
    }
  });

  // Mock Auto DS product sync
  app.post("/api/autods/sync-products", async (req, res) => {
    try {
      // Simulate product sync process
      setTimeout(() => {
        res.json({ 
          message: "Product sync initiated successfully",
          productsUpdated: 1247,
          timestamp: new Date().toISOString()
        });
      }, 1000);
    } catch (error: any) {
      res.status(500).json({ message: "Error syncing products: " + error.message });
    }
  });

  // ZED Chatbot endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, context } = req.body;
      
      // Smart response logic based on keywords and context
      const response = generateChatbotResponse(message.toLowerCase());
      
      res.json({ reply: response });
    } catch (error: any) {
      res.status(500).json({ 
        reply: "I'm having trouble processing your request right now. Please try again or contact our support team for immediate assistance." 
      });
    }
  });

  // Admin Authentication
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Simple admin authentication (in production, use proper authentication)
      if (username === "admin" && password === "zupreme2025") {
        const token = "admin-token-" + Date.now();
        res.json({ 
          success: true, 
          token,
          message: "Login successful" 
        });
      } else {
        res.status(401).json({ 
          success: false, 
          message: "Invalid credentials" 
        });
      }
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        message: "Login error: " + error.message 
      });
    }
  });

  // Admin Stats
  app.get("/api/admin/stats", async (req, res) => {
    try {
      // Mock admin statistics
      const stats = {
        totalProducts: 156,
        revenue: 25400,
        totalOrders: 89,
        growth: 12,
        shopifyIntegration: {
          status: "connected",
          products: 142,
          lastSync: new Date(Date.now() - 15 * 60 * 1000).toISOString()
        },
        ebayIntegration: {
          status: "connected", 
          activeListings: 67,
          soldItems: 34,
          lastSync: new Date(Date.now() - 8 * 60 * 1000).toISOString()
        }
      };
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching stats: " + error.message });
    }
  });

  // Admin Products Management
  app.get("/api/admin/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching products: " + error.message });
    }
  });

  app.post("/api/admin/products", async (req, res) => {
    try {
      const productData = req.body;
      const product = await storage.createProduct(productData);
      
      // Sync to Shopify if configured
      if (productData.syncToShopify) {
        await syncProductToShopify(product);
      }
      
      // Create eBay listing if configured
      if (productData.syncToEbay && productData.category === "sports-cards") {
        await createEbayListing(product);
      }
      
      res.json(product);
    } catch (error: any) {
      res.status(400).json({ message: "Error creating product: " + error.message });
    }
  });

  app.put("/api/admin/products/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const productData = req.body;
      const product = await storage.updateProduct(id, productData);
      res.json(product);
    } catch (error: any) {
      res.status(400).json({ message: "Error updating product: " + error.message });
    }
  });

  app.delete("/api/admin/products/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteProduct(id);
      res.json({ message: "Product deleted successfully" });
    } catch (error: any) {
      res.status(400).json({ message: "Error deleting product: " + error.message });
    }
  });

  // Shopify Integration Endpoints
  app.post("/api/admin/shopify/sync", async (req, res) => {
    try {
      const result = await syncAllProductsToShopify();
      res.json({
        success: true,
        message: "Shopify sync completed",
        syncedProducts: result.count,
        timestamp: new Date().toISOString()
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false,
        message: "Shopify sync failed: " + error.message 
      });
    }
  });

  app.get("/api/admin/shopify/status", async (req, res) => {
    try {
      const status = await getShopifyStatus();
      res.json(status);
    } catch (error: any) {
      res.status(500).json({ message: "Error checking Shopify status: " + error.message });
    }
  });

  // eBay Integration Endpoints
  app.post("/api/admin/ebay/sync", async (req, res) => {
    try {
      const result = await syncSportsCardsToEbay();
      res.json({
        success: true,
        message: "eBay sync completed", 
        createdListings: result.count,
        timestamp: new Date().toISOString()
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false,
        message: "eBay sync failed: " + error.message 
      });
    }
  });

  app.get("/api/admin/ebay/status", async (req, res) => {
    try {
      const status = await getEbayStatus();
      res.json(status);
    } catch (error: any) {
      res.status(500).json({ message: "Error checking eBay status: " + error.message });
    }
  });

  // Admin Settings Management
  app.get("/api/admin/settings", async (req, res) => {
    try {
      // Mock store settings
      const settings = {
        store: {
          name: "Zupreme Imports",
          description: "Premium vintage sports cards, trending imports, and rare collectibles. Your trusted source for authentic memorabilia and unique finds.",
          contactEmail: "support@zupremeimports.com",
          phone: "+1 (555) 123-4567"
        },
        payment: {
          stripe: true,
          paypal: true,
          crypto: false,
          shippingRate: 5.99,
          freeShippingThreshold: 50.00,
          taxRate: 8.25
        },
        automation: {
          autoImport: true,
          priceMonitoring: true,
          stockSync: true,
          syncFrequency: "hourly",
          orderAlerts: true,
          stockAlerts: true,
          syncErrors: true
        },
        seo: {
          metaTitle: "Zupreme Imports - Premium Sports Cards & Collectibles",
          metaDescription: "Discover rare vintage sports cards, trending imports, and premium collectibles. Authentic memorabilia with fast shipping and satisfaction guarantee.",
          keywords: "sports cards, collectibles, vintage cards, trading cards, memorabilia",
          socialMedia: {
            facebook: "@zupremeimports",
            instagram: "@zupremeimports",
            twitter: "@zupremeimports"
          }
        },
        security: {
          twoFactor: false,
          loginAlerts: true,
          autoLogout: true
        }
      };
      res.json(settings);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching settings: " + error.message });
    }
  });

  app.put("/api/admin/settings/:section", async (req, res) => {
    try {
      const { section } = req.params;
      const settingsData = req.body;
      
      // In a real implementation, this would save to database
      res.json({ 
        success: true, 
        message: `${section} settings updated successfully`,
        data: settingsData
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false,
        message: "Error updating settings: " + error.message 
      });
    }
  });

  // System Diagnostics & Optimization
  app.get("/api/admin/diagnostics", async (req, res) => {
    try {
      const { diagnostics } = await import("./diagnostics");
      const health = await diagnostics.runFullDiagnostics();
      res.json(health);
    } catch (error: any) {
      res.status(500).json({ message: "Error running diagnostics: " + error.message });
    }
  });

  app.post("/api/admin/optimize", async (req, res) => {
    try {
      const { optimizer } = await import("./optimization");
      const results = await optimizer.optimizeStorage();
      res.json({ 
        success: true, 
        message: "Storage optimization completed",
        results 
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false,
        message: "Error optimizing storage: " + error.message 
      });
    }
  });

  app.get("/api/admin/export/:type", async (req, res) => {
    try {
      const { exporter } = await import("./export");
      const { type } = req.params;
      
      let result;
      switch (type) {
        case "products":
          result = await exporter.exportProducts({ format: "json" });
          break;
        case "sports-cards":
          result = await exporter.exportSportsCards({ format: "json" });
          break;
        case "configuration":
          result = await exporter.exportConfiguration();
          break;
        case "diagnostics":
          result = await exporter.exportDiagnostics();
          break;
        case "all":
          const allResults = await exporter.exportAllData();
          result = { exports: allResults, summary: "All data exported successfully" };
          break;
        default:
          return res.status(400).json({ message: "Invalid export type" });
      }
      
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ 
        success: false,
        message: "Error exporting data: " + error.message 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Smart chatbot response generator
function generateChatbotResponse(message: string): string {
  // Sports cards related queries
  if (message.includes("sports card") || message.includes("card") || message.includes("basketball") || message.includes("jordan") || message.includes("rookie")) {
    return "I'd love to help you find the perfect sports cards! Our Sports Cards Vault features authenticated vintage cards including rare rookie cards. You can browse our collection and either purchase directly or bid on eBay auctions. What type of cards are you looking for?";
  }
  
  // Pricing and payment queries
  if (message.includes("price") || message.includes("cost") || message.includes("payment") || message.includes("buy")) {
    return "Our prices are competitive and we offer secure payment processing through Stripe. For sports cards, you can either buy directly at listed prices or participate in eBay auctions for potentially better deals. Would you like me to show you specific products or explain our payment options?";
  }
  
  // Shipping and delivery
  if (message.includes("ship") || message.includes("delivery") || message.includes("how long")) {
    return "We offer fast and secure shipping on all orders. Most items ship within 1-2 business days. For sports cards, we use protective packaging to ensure your collectibles arrive safely. Shipping costs and timeframes vary by location. Would you like specific shipping information for an item?";
  }
  
  // Product browsing
  if (message.includes("browse") || message.includes("shop") || message.includes("products") || message.includes("marketplace")) {
    return "You can browse our full collection in the Marketplace section, or visit our specialized Sports Cards Vault for authenticated collectibles. We also have trending products and curated bundles. What type of items interest you most?";
  }
  
  // Authentication and quality
  if (message.includes("authentic") || message.includes("real") || message.includes("genuine") || message.includes("quality")) {
    return "All our sports cards go through professional authentication to ensure you're getting genuine collectibles. We work with trusted sources and provide detailed condition reports. Your satisfaction and the authenticity of our products are our top priorities.";
  }
  
  // Help with navigation
  if (message.includes("help") || message.includes("how") || message.includes("where") || message.includes("find")) {
    return "I'm here to help! You can navigate using our main menu: Home for featured items, Sports Cards Vault for collectibles, and Marketplace for all products. You can also use the search function or I can guide you to specific categories. What are you looking for?";
  }
  
  // ZWAP integration
  if (message.includes("zwap") || message.includes("app")) {
    return "Great question! We're integrated with the ZWAP! app for seamless product synchronization and enhanced shopping features. You can access ZWAP! through our footer links for additional functionality and curated content.";
  }
  
  // Contact and support
  if (message.includes("contact") || message.includes("support") || message.includes("problem") || message.includes("issue")) {
    return "I'm here to help resolve any issues! For immediate assistance, you can use this chat or visit our Contact page for direct communication with our support team. We're committed to providing excellent customer service.";
  }
  
  // General greeting
  if (message.includes("hello") || message.includes("hi") || message.includes("hey") || message.includes("good")) {
    return "Hello! Welcome to Zupreme Imports. I'm ZED, your personal shopping assistant. I can help you find sports cards, browse our marketplace, answer questions about products, or guide you through the purchasing process. How can I assist you today?";
  }
  
  // Default response for unmatched queries
  return "That's a great question! I can help you with sports cards, product information, pricing, shipping, and navigating our store. You can browse our Sports Cards Vault for authenticated collectibles or check out our Marketplace for trending products. Is there something specific you'd like to know about our products or services?";
}

// Shopify Integration Functions
async function syncProductToShopify(product: any) {
  // Mock Shopify API integration
  console.log(`Syncing product ${product.name} to Shopify...`);
  // In production, implement actual Shopify API calls
  return { success: true, shopifyId: `shopify_${Date.now()}` };
}

async function syncAllProductsToShopify() {
  // Mock bulk sync to Shopify
  console.log("Syncing all products to Shopify...");
  return { success: true, count: 142 };
}

async function getShopifyStatus() {
  return {
    connected: true,
    storeUrl: "zupreme-imports.myshopify.com",
    products: 142,
    lastSync: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    syncStatus: "active"
  };
}

// eBay Integration Functions  
async function createEbayListing(product: any) {
  // Mock eBay API integration
  console.log(`Creating eBay listing for ${product.name}...`);
  // In production, implement actual eBay API calls
  return { success: true, listingId: `ebay_${Date.now()}` };
}

async function syncSportsCardsToEbay() {
  // Mock sports cards sync to eBay
  console.log("Syncing sports cards to eBay...");
  return { success: true, count: 67 };
}

async function getEbayStatus() {
  return {
    connected: true,
    sellerId: "zupreme_imports",
    activeListings: 67,
    soldItems: 34,
    lastSync: new Date(Date.now() - 8 * 60 * 1000).toISOString(),
    fees: { listing: 0.35, final: 10.2 }
  };
}
