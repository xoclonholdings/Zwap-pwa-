# Zupreme Imports - Web Host Deployment

## Quick Deployment Steps

1. **Upload Files**: Upload all files to your web host
2. **Install Dependencies**: Run `npm install`
3. **Configure Environment**: Copy `.env.example` to `.env` and configure
4. **Start Application**: Run `npm start`

## Admin Access
- URL: `/admin/login`
- Username: `admin`
- Password: `zupreme2025`

⚠️ **Change the default password immediately!**

## Features Included
- ✅ Complete e-commerce store
- ✅ Sports cards vault
- ✅ Admin dashboard
- ✅ Product management
- ✅ Marketplace integrations (Shopify, eBay)
- ✅ Configuration system
- ✅ System diagnostics
- ✅ Data export/import

## Support
See `docs/admin-setup-guide.md` for detailed configuration instructions.
